#!/bin/sh

while [ 1 ]
do
pg_dump -h 192.168.100.107 -U pgsql tpcw10 > pangea.dump
echo "hello"
done
