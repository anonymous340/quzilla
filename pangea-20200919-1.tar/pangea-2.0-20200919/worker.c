/*
 * copyright (c) 2020 
 */

#include "pangea.h"
#include "worker.h"

void *
worker(void *arg) {
  int tid;   /* obusoluted */
  Task *task;
  
  tid = *(int *)arg;
	
  task = GetMytaskFromWaitQueue(tid);
  PutMyTaskToRunQueue(task);
  if ( strcmp (task->InitPacket.startup_packet+13, sys->OLTPUser) == 0 ) {  // OLTP transaction
    CreateAllBackendConnection(task);
    SendAllStartupPacket(task);
    RecvAll(task);
    SendClient(task, task->OLTPNode);
  } else if ( strcmp ( task->InitPacket.startup_packet+13, sys->OLAPUser ) == 0 ) {   // OLAP transaction
    CreateOLAPBackendConnection(task);
    SendOLAPStartupPacket(task);
    RecvOneServer(task, task->mynode);
    SendClient(task, task->mynode);
  } else {
    printf("user error: %s \n", task->InitPacket.startup_packet+13);
  }

    /* handle transaction */
    while ( 1 ) {
      RecvAndParseQuery(task);
      switch ( task->ttype ) {
      case OLTP:
	switch ( task->status ) {
	case OLTP_IDLE:
	  ExecuteOLTP_FOR_IDLE(task);
	  break;
	case OLTP_SNAPSHOT_CREATED:
	  ExecuteOLTP_FOR_SNAPSHOT_CREATED(task);
	  break;
	default:
	  printf("OLTP status error: %p:%d\n", task, task->status);
	  exit(EXIT_FAILURE);
	}
	break;
      case OLAP:
	switch ( task->status ) {
	case OLAP_IDLE:
	  ExecuteOLAP_FOR_IDLE(task);
	  break;
	case OLAP_SNAPSHOT_CREATED:
	  ExecuteOLAP_FOR_SNAPSHOT_CREATED(task);
	  break;
	default:
	  printf("OLAP status error:  %p:%d\n",  task, task->status);
	  exit(EXIT_FAILURE);
	}
	break;
      case SETTRAN:
	ExecuteSET(task);
	break;
      default:
	printf("unknown transaction type\n");
	exit(EXIT_FAILURE);
      }
      ResetTask(task);
    } // while end
    FinishConnection(task);
    DestroyTask(task);
  	
    return NULL;
}

Task *
GetMytaskFromWaitQueue(int tid) {
  Queue *wq;   /* wait queue */
  Task *mytask, *head, *neck, *shoulder;
  
  wq = &database[tid].wait_queue;

  pthread_mutex_lock(wq->queue_mutex);

  while( wq->len == 0 )
    pthread_cond_wait(wq->queue_cond, wq->queue_mutex);
  
  head = &wq->head;
  neck = head->next;
  shoulder = neck->next;
  
  mytask = neck;
  if (mytask == NULL) {
    printf("mytask is NULL!\n");
    exit(1);
  }
		
  if ( -- wq->len == 0 )
    head->next = head->prev = head;
  else {
    head->next = neck->next;
    shoulder->prev = head;
  }
  
  pthread_mutex_unlock(wq->queue_mutex);

  return mytask;
}

void
PutMyTaskToRunQueue(Task *task) {
  Queue *rq; /* run queue */
  Task *head, *tail;
  
  rq = &database[task->database_id].run_queue;

  pthread_mutex_lock(rq->queue_mutex);
	
  head = &rq->head;
  tail = head->prev;

  tail->next = task;
  head->prev = task;
  task->next = head;
  task->prev = tail;

  pthread_mutex_unlock(rq->queue_mutex);

  return;
}

void
FinishConnection(Task *task) {
  int i;

  close(task->client->fd);
  for (i = 0; i < database[task->database_id].server.numactsrv; i++) {
    close(task->server[i]->fd);
  }
  return;
}

void
RecvAndParseQuery2(Task *task) {
  int bufhead = 0;
  int bufcur = 0;
  int bufsize = QUERYBUFSZ;
  int recved = 0;
  int remained = 0;
  int *packetlen;

  packetlen = &task->client->packetlen;
  *packetlen = 0;

  while ( 1 ) {
    /*
     * We try to receive some data from the socket.
     * Note that we may not receive all data.
     */

    recved = Recv2(task->client->fd, task->client->packet + bufhead, bufsize - bufhead);
    *packetlen += recved;
    bufhead += recved;
    bufsize -= recved;

    /* We check whether we have received all data or not */
    if ( ParseQuery(task, &bufcur, recved + remained, &remained) == 0)
      /* We have received all data successfully */
      break;
  } /* while end */

  return;
}

int
ParseQuery(Task *task, int *cur, int datalen, int *remained) {
  int strlen;
  void *p;
  char command;

  p = (void *)task->client->packet;

#ifdef PARSE_DEBUG
  printf("--- send start %p ---\n", task);
#endif

  while(datalen > 0){
    GetChar(&command, p + *cur, 1);
    GetInt(&strlen,  p + *cur + 1, 4);
    ParseQuery2(task, command, cur, datalen - strlen - 1);
    if (datalen >= strlen + 1) {
      datalen -= strlen + 1;
      *cur += strlen + 1;
    }
    else {
      /* return to re-receive data length */
      *remained = datalen;
      return 1;
    }
  } /* while end */

#ifdef PARSE_DEBUG
  printf("--- send end %p ---\n\n", task);
#endif

  //  if ( (command == 'S' || command == 'Z') && datalen == 0){
  if ( datalen == 0 ){
    /* we have received all data successfully */
    return 0;
  }
  else if (datalen == 0) {
    /* Eventually datalen equals 0 but we have not received all data yet */
    *remained = 0;
    return 1;
  }
  else {
    /* not reached */
    printf("[FATAL] ParseQuery() Error\n");
    exit(EXIT_FAILURE);
  }
}

void
ParseQuery2(Task *task, char command, int *cur, int len) {
  char *statement;

   statement = task->client->packet + *cur + 5;

  switch(command)
    {
    case 'P':
      if ( ( strncmp(statement, "S_1", 3) == 0 ) ){
	task->this_commit_query_type = 1;
	task->qtype = COMMIT;
	if ( strncmp(statement + 4, "COMMIT", 3) == 0 ) {
	  task->commit_query_type[task->this_commit_query_type] = COMMIT_QUERY;
	}
	else {
	  task->commit_query_type[task->this_commit_query_type] = ROLLBACK_QUERY;
	}
      }
      else if ( strncmp(statement, "S_2", 3) == 0) {
	task->this_commit_query_type = 2;
	task->qtype = COMMIT;
	if ( strncmp(statement + 4, "COMMIT", 3) == 0 ) {
	  task->commit_query_type[task->this_commit_query_type] = COMMIT_QUERY;
	}
	else {
	  task->commit_query_type[task->this_commit_query_type] = ROLLBACK_QUERY;
	}
      }
      else if ( strncmp(statement, "S_", 2) == 0) {
	task->this_commit_query_type = 3;
	task->qtype = COMMIT;
	if ( strncmp(statement + 4, "COMMIT", 3) == 0 ) {
	  task->commit_query_type[task->this_commit_query_type] = COMMIT_QUERY;
	}
	else {
	  task->commit_query_type[task->this_commit_query_type] = ROLLBACK_QUERY;
	}
      }
      else if (strncmp(statement + 1, "PREPARE TRANSACTION", 19) == 0) {
	task->qtype = PREPARE;
      }
      else if ( (strncmp(statement + 1, "COMMIT PREPARED", 15) == 0) ) {
	task->this_commit_query_type = 0;
	task->qtype = COMMIT;
      }      
      else if ( (strncmp(statement + 1, "/* OLTP", 7) == 0) ) {
	task->ttype = OLTP;
	task->qtype = SNAPSHOT;
	task->status = OLTP_IDLE;
      }
      else if ( (strncmp(statement + 1, "/* OLAP", 7) == 0) ) {
	task->ttype = OLAP;
	task->qtype = READ;
	task->status = OLAP_IDLE;
      }
      else if ( (strncmp(statement + 1, "CREATE", 6) == 0) || (strncmp(statement + 1, "DROP", 4) == 0) ) {
	task->ttype = OLAP;
	task->qtype = READ;	
      }
      else if ( (strncmp(statement + 1, "SELECT", 6) == 0) ) {
	task->qtype = READ;
      }
      else if ( strncmp(statement + 1, "/* WRITE", 8) == 0 ) {
	task->qtype = WRITE;
	//	printf("su: %p: %s\n", task, (char *)(statement + 1));
      }
      else if ( strncmp(statement + 1, "UPDATE", 6) == 0 || strncmp(statement + 1, "DELETE", 6) == 0 || strncmp(statement + 1, "INSERT", 6) == 0 ) {
	task->qtype = WRITE;
      }
      else if ( (strncmp(statement + 1, "BEGIN", 5) == 0) ) {
	task->ttype = OLTP;
	task->qtype = SNAPSHOT;
      }
      else if (strncmp(statement + 1, "ABORT", 5) == 0) {
	task->qtype = ABORT;
      }
      else if (strncmp(statement + 1, "COMMIT", 6) == 0) {
	task->qtype = COMMIT;
      }
      else if (strncmp(statement + 1, "LOCK", 4) == 0) {
	task->qtype = LOCK;
      }
      else if (strncmp(statement + 1, "SET extra", 9) == 0) {
        task->ttype = SETTRAN;
      }
      else if (strncmp(statement + 1, "SET SESSION", 11) == 0) {
	task->ttype = SETTRAN;
      }
      else if (strncmp(statement + 1, "SET", 3) == 0) {
	task->ttype = SETTRAN;
      }
      else {
	printf("statement parse error: %s\n", (char *)(statement + 1));
	exit(EXIT_FAILURE);
      }
#ifdef PARSE_DEBUG
      if ( strncmp(statement, "S_", 2) == 0) 
	printf("%p: [%c] [%s] [%d]\n", task, command, statement, len);
      else
	printf("%p: [%c] [%s] [%d]\n", task, command, statement + 1, len);	
#endif
      break;
    case 'B':
      if ( ( strncmp(statement+1, "S_1", 3) == 0 ) ) {
		task->qtype = COMMIT;
	//	task->qtype = ROLLBACK;
	task->this_commit_query_type = 1;
	if ( task->commit_query_type[task->this_commit_query_type] == ROLLBACK_QUERY ) {
	  memcpy(task->rollback_packet, task->client->packet, task->client->packetlen);
	  task->rollback_packetlen = task->client->packetlen;
	}
      }
      else if ( strncmp(statement+1, "S_2", 3) == 0) {
	task->qtype = COMMIT;
	//	task->qtype = ROLLBACK;
	task->this_commit_query_type = 2;
	if ( task->commit_query_type[task->this_commit_query_type] == ROLLBACK_QUERY ) {
	  memcpy(task->rollback_packet, task->client->packet, task->client->packetlen);
	  task->rollback_packetlen = task->client->packetlen;
	}
      }
      else if ( strncmp(statement+1, "S_", 2) == 0) {
	task->qtype = COMMIT;
	//	task->qtype = ROLLBACK;
	task->this_commit_query_type = 3;
      }
#ifdef PARSE_DEBUG
	printf("%p: [%c] [%s] [%d]\n", task, command, statement+1, len);
#endif
      break;
    case 'D':
    case 'E':
#ifdef PARSE_DEBUG
      printf("%p: [%c] [%s] [%d]\n", task, command, statement, len);
#endif
    break;
    case 'S':
#ifdef PARSE_DEBUG
      printf("%p: [%c] [] [%d]\n", task, command, len);
#endif
      break;
    case 'Q':
      if ( ( strncmp(statement, "/* OLTP */ BEGIN", 16) == 0) || ( strncmp(statement, "/* OLTP +/ begin", 16) == 0) ) {
	task->qtype = BEGIN;
	task->ttype = OLTP;
	task->status = OLTP_IDLE;
#ifdef PARSE_DEBUG
	printf("[%c] [%s] [%d]\n", command, statement, len);
#endif
      }
      else if ( ( strncmp(statement, "/* OLAP */ BEGIN", 16) == 0) || ( strncmp(statement, "/* OLAP */ begin", 16) == 0) ) {
	task->qtype = BEGIN;
	task->ttype = OLAP;
	task->status = OLAP_IDLE;
#ifdef PARSE_DEBUG
	printf("[%c] [%s] [%d]\n", command, statement, len);
#endif
      }
      else if ( ( strncmp(statement + 1, "/* READ", 7) == 0)  ) {
	task->qtype = READ;
#ifdef PARSE_DEBUG
	printf("[%c] [%s] [%d]\n", command, statement, len);
#endif
      }
      else if ( ( strncmp(statement + 1, "/* WRITE", 8) == 0)  ) {
	task->qtype = WRITE;
#ifdef PARSE_DEBUG
	printf("[%c] [%s] [%d]\n", command, statement, len);
#endif
      }
      else if ( ( strncmp(statement, "COMMIT", 6) == 0) || ( strncmp(statement, "commit", 6) == 0) ) {
	task->qtype = COMMIT;
#ifdef PARSE_DEBUG
	printf("[%c] [%s] [%d]\n", command, statement, len);
#endif
      }
      else if ( ( strncmp(statement, "PREPARE", 7) == 0) || ( strncmp(statement, "prepare", 7) == 0) ) {
	task->qtype = PREPARE;
#ifdef PARSE_DEBUG
	printf("[%c] [%s] [%d]\n", command, statement, len);
#endif
      }
      else if ( ( strncmp(statement, "ABORT", 5) == 0) || ( strncmp(statement, "abort", 5) == 0) ) {
	task->qtype = ABORT;
#ifdef PARSE_DEBUG
	printf("[%c] [%s] [%d]\n", command, statement, len);
#endif
      }
      else if ( ( strncmp(statement, "SELECT", 6) == 0) || ( strncmp(statement, "select", 6) == 0) ) {
	task->qtype = READ;
#ifdef PARSE_DEBUG
	printf("[%c] [%s] [%d]\n", command, statement, len);
#endif
      }
      else if ( ( strncmp(statement, "ROLLBACK", 8) == 0) || ( strncmp(statement, "rollback", 8) == 0) ) {
	task->qtype = ABORT;
#ifdef PARSE_DEBUG
	printf("[%c] [%s] [%d]\n", command, statement, len);
#endif
      }
      else if (strncmp(statement, "/* RO */", 8) == 0) {
	task->qtype = READ;
	task->ttype = OLAP;
#ifdef PARSE_DEBUG
	printf("[%c] [%s] [%d]\n", command, statement, len);
#endif
      }
      else if ( (strncmp(statement, "UPDATE", 6) == 0)	|| (strncmp(statement, "DELETE", 6) == 0) || (strncmp(statement, "/* WRITE */", 11) == 0) || (strncmp(statement, "update", 6) == 0) || (strncmp(statement, "delete", 6) == 0) || (strncmp(statement, "INSERT", 6) == 0) ) {
	task->qtype = WRITE;
#ifdef PARSE_DEBUG
	printf("[%c] [%s] [%d]\n", command, statement, len);
#endif
      }
      else if ( (strncmp(statement, "LOCK", 4) == 0) || (strncmp(statement, "lock", 4) == 0) ){
	task->qtype = LOCK;
#ifdef PARSE_DEBUG
	printf("[%c] [%s] [%d]\n", command, statement, len);
#endif
      }
      else {
	task->qtype = OTHER;
#ifdef PARSE_DEBUG
	printf("[%c] [%s] [%d]\n", command, statement, len);
#endif
      }
      break;
#ifdef PARSE_DEBUG
      printf("[%c] [%s] [%d]\n", command, statement, len);		 
#endif
      break;
    case 'X':
      task->qtype = DISCONN;
      sleep(1000);
#ifdef PARSE_DEBUG
      printf("[%c] [%s] [%d]\n", command, statement, len);
#endif
      break;
    default:
      printf("Oh, unexpected command [%c] [%s] : [%d]\n", command, statement, len);
      break;
    } /* swith end */
  return;
}

void
DestroyTask(Task *task) {
  int i;

  for (i = 0; i < sys->NumOLTPNode + sys->NumOLAPNode; i++) {
    free(task->server[i]->packet);
    free(task->server[i]);
  }
  free(task->server);
  free(task->client->packet);
  free(task->client);
  free(task);
  return;
}

void
DisconnExecution(Task *task) {
  SendAll(task);
  return;
}

void
ResetTask(Task *task) {
  int i;
  if ( task->qtype == COMMIT || task->qtype == ABORT )
    task->qtype = NOQUERY;
  for ( i = 0; i < sys->NumOLTPNode + sys->NumOLAPNode; i++) {
    task->server[i]->error = NOERROR;
  }
  return;
}

void
RecvAndParseQuery(Task *task) {
  RecvAndParseQuery2(task);
  return;
}

void
CopyInitPacket(Task *task) {
  if ( sys->InitPacket.InitFlag != SET_VALID ){
    pthread_mutex_lock(sys->InitPacket.InitFlagMutex);
    if ( sys->InitPacket.InitFlag != SET_VALID ) {
      memcpy(sys->InitPacket.startup_packet, task->InitPacket.startup_packet, task->InitPacket.startup_packetlen);
      sys->InitPacket.startup_packetlen = task->InitPacket.startup_packetlen;
      memcpy(sys->InitPacket.setup1_packet, task->InitPacket.setup1_packet, task->InitPacket.setup1_packetlen);
      sys->InitPacket.setup1_packetlen = task->InitPacket.setup1_packetlen;
      memcpy(sys->InitPacket.setup2_packet, task->InitPacket.setup2_packet, task->InitPacket.setup2_packetlen);
      sys->InitPacket.setup2_packetlen = task->InitPacket.setup2_packetlen;
      sys->InitPacket.InitFlag = SET_VALID;
    }
    pthread_cond_broadcast(sys->InitPacket.InitFlagCond);
    pthread_mutex_unlock(sys->InitPacket.InitFlagMutex);
  }
  return;
}

void
ExecuteSET(Task *task) {

  if (task->OLTPNode > -1 ) {// OLTP
    SendAll(task);
    RecvAll(task);
    SendClient(task, task->mynode);
  } else {   // OLAP
    SendOneServer(task, task->mynode);
    RecvOneServer(task, task->mynode);
    SendClient(task, task->mynode);
  }
  return;
}

void
ExecuteOLTP_FOR_IDLE(Task *task) {

  switch ( task->qtype ) {
  case READ:
  case SNAPSHOT:
    ExecuteReadSyncForOLTP(task);
    task->status = OLTP_SNAPSHOT_CREATED;
    break;
  case WRITE:
    ExecuteSelect1Sync(task);
    LeaderFollowerExecution(task);
    task->status = OLTP_SNAPSHOT_CREATED;    
    break;
  case COMMIT:
  case ROLLBACK:
  case BEGIN:
    SendAll(task);
    RecvAll(task);
    SendClient(task, task->mynode);
    break;
  default:
    printf("ExecuteOLTP_FOR_IDLE error\n");
    sleep(1000);
    break;
  }

  return;  
}

void
ExecuteOLTP_FOR_SNAPSHOT_CREATED(Task *task) {
  int tmp;
  switch ( task->qtype ) {
  case READ:
    SendOneServer(task, task->mynode);
    RecvOneServer(task, task->mynode);
    if ( ( tmp = CheckDangerousStructure(task) ) ) {
        pthread_mutex_lock(&read_dangerous_structure_counter_mutex);
	read_dangerous_structure_counter += tmp;
	pthread_mutex_unlock(&read_dangerous_structure_counter_mutex);
    }
    Send(task->client->fd, task->server[task->mynode]->packet, task->server[task->mynode]->packetlen);
    break;
  case WRITE:
    LeaderFollowerExecution(task);
    if ( ( tmp = CheckDangerousStructure(task) ) ) {
        pthread_mutex_lock(&write_dangerous_structure_counter_mutex);
	write_dangerous_structure_counter += tmp;
	pthread_mutex_unlock(&write_dangerous_structure_counter_mutex);
    }	
    break;
  case PREPARE:
    //    printf("pangea-2.0 cannot execute PREPARE query\n");
    //    exit(EXIT_FAILURE);
    SendAll(task);
    RecvAll(task);
    Send(task->client->fd, task->server[0]->packet, task->server[0]->packetlen);
    break;
  case COMMIT:
    if ( task->this_commit_query_type == 0 )
      ExecuteCommitSyncForOLTP(task);
    else if ( task->commit_query_type[task->this_commit_query_type] == COMMIT_QUERY )
      ExecuteCommitSyncForOLTP(task);
    else if ( task->commit_query_type[task->this_commit_query_type] == ROLLBACK_QUERY ) {
      SendAll(task);
      RecvAll(task);
      Send(task->client->fd, task->server[0]->packet, task->server[0]->packetlen);
    } else {
      printf("COMMIT query type error: %d\n", task->commit_query_type[task->this_commit_query_type]);
      exit(EXIT_FAILURE);
    }
    task->status = OLTP_IDLE;
    task->this_commit_query_type = 0;
    break;
  case ROLLBACK:
  default:
    printf("cannot %p qtype error:%d: %s\n", task, task->qtype, (char *)(task->client->packet + 6));
    exit(EXIT_FAILURE);
  }
  return;
}

void
ExecutePrepareAndCommitSyncForOLTP(Task *task) {
  int i;
  ERR found_error = NOERROR;

  // block snapshot creation
  pthread_mutex_lock(&snapshot_commit_mutex.snapshot_commit_mutex);
  while ( snapshot_commit_mutex.snapshot_executing > 0 )
    pthread_cond_wait(&snapshot_commit_mutex.commit_cond, &snapshot_commit_mutex.snapshot_commit_mutex);
  snapshot_commit_mutex.commit_executing ++;
  pthread_mutex_unlock(&snapshot_commit_mutex.snapshot_commit_mutex);

  // block commits for OLAP
  pthread_mutex_lock(&commit_mutex.commit_OLTP_OLAP_mutex);
  while ( commit_mutex.commit_OLAP_executing > 0 )
    pthread_cond_wait(&commit_mutex.commit_OLTP_cond, &commit_mutex.commit_OLTP_OLAP_mutex);
  commit_mutex.commit_OLTP_executing ++;
  pthread_mutex_unlock(&commit_mutex.commit_OLTP_OLAP_mutex);

  // send PREPARE TRANSACTION
  
  SendPrepareToOLTPLeader(task);
  RecvDataFromOne(task, 0);
  if ( task->server[0]->error == NOERROR ) {
    SendPrepareToOthers(task);
    RecvOthers(task);
  }

  for ( i = 0; i < sys->NumOLTPNode + sys->NumOLAPNode; i++ ) {
    if ( task->server[i]->error != NOERROR ) {
      found_error = task->server[i]->error;
      break;
    }
  }

  // send COMMIT PREPARED
  if ( found_error == NOERROR && task->commit_query_type[task->this_commit_query_type] == COMMIT_QUERY ) {
    SendCommitAsync(task);
    RecvAll(task);
  } else if ( found_error == NOERROR && task->commit_query_type[task->this_commit_query_type] == TRY_COMMIT_QUERY ) {
    SendCommitAsync(task);
    RecvAll(task);
    task->commit_query_type[task->this_commit_query_type] = COMMIT_QUERY;
  }

  // release commits for OLAP
  pthread_mutex_lock(&commit_mutex.commit_OLTP_OLAP_mutex);
  commit_mutex.commit_OLTP_executing --;
  if ( commit_mutex.commit_OLTP_executing == 0 )
    pthread_cond_broadcast(&commit_mutex.commit_OLAP_cond);
  pthread_mutex_unlock(&commit_mutex.commit_OLTP_OLAP_mutex);

  // release snapshot creation
  pthread_mutex_lock(&snapshot_commit_mutex.snapshot_commit_mutex);
  snapshot_commit_mutex.commit_executing --;
  if ( snapshot_commit_mutex.commit_executing == 0 )
    pthread_cond_broadcast(&snapshot_commit_mutex.snapshot_cond);
  pthread_mutex_unlock(&snapshot_commit_mutex.snapshot_commit_mutex);

  // send a response to the client
  // no error
  if ( found_error == NOERROR ) {
    if (task->commit_counter++ == 0 ) {
      Send(task->client->fd, task->commit_success1_packet, task->commit_success1_packetlen);
      task->commit_query_type[task->this_commit_query_type] = COMMIT_QUERY;
    } else if ( task->commit_counter > 0 )
      Send(task->client->fd, task->commit_success2_packet, task->commit_success2_packetlen);
  }
  // decide ROLLBACK query
  else if ( found_error == ROLLBACK_ERROR && task->commit_query_type[task->this_commit_query_type] == TRY_COMMIT_QUERY ) {
    Send(task->client->fd, task->rollback1_packet, task->rollback1_packetlen );
    task->commit_query_type[task->this_commit_query_type] = ROLLBACK_QUERY;
  }
  // decided error query  
  else if ( found_error == SERROR && task->commit_query_type[task->this_commit_query_type] == TRY_COMMIT_QUERY ) {
    printf("try commit and serror:%p\n", task);
    Send(task->client->fd, task->commit_error1_packet, task->commit_error1_packetlen);
    task->commit_query_type[task->this_commit_query_type] = ERROR_QUERY;
  }
  // fail PREPARE query and ROLLBACK_ERROR
  else if ( found_error == ROLLBACK_ERROR && task->commit_query_type[task->this_commit_query_type] == COMMIT_QUERY ) {
    //    SendRollbackPrepared(task);
    Send(task->client->fd, task->commit_error2_packet, task->commit_error2_packetlen);
  }
  // fail PREPARE query and SERROR
  else if ( found_error == SERROR && task->commit_query_type[task->this_commit_query_type] == COMMIT_QUERY ) {
    //    SendRollbackPrepared(task);
    Send(task->client->fd, task->commit_error2_packet, task->commit_error2_packetlen);
  }
  else {
    printf("PREPARE COMMIT error\n");
    exit(EXIT_FAILURE);
  }
  return;
}


void
ExecutePrepareSyncForOLTP(Task *task) {
  int i;
  ERR error_server[16];
  int found_error = -1;
  
  memcpy(task->tmp_packet, task->client->packet, 31);
  snprintf(task->tmp_packet + 31, 5, "%d", task->thread_id);
  memcpy(task->tmp_packet + 35, task->client->packet + 35, task->client->packetlen - 35);
  memcpy(task->client->packet, task->tmp_packet, task->client->packetlen);
#ifdef PARSE_DEBUG
  printf("%p: COMMIT ID: %s\n", task, (char *)(task->client->packet + 31));
#endif
  
  // block snapshot creation
  pthread_mutex_lock(&snapshot_commit_mutex.snapshot_commit_mutex);
  while ( snapshot_commit_mutex.snapshot_executing > 0 )
    pthread_cond_wait(&snapshot_commit_mutex.commit_cond, &snapshot_commit_mutex.snapshot_commit_mutex);
  snapshot_commit_mutex.commit_executing ++;
  pthread_mutex_unlock(&snapshot_commit_mutex.snapshot_commit_mutex);

  // block commits for OLAP
  pthread_mutex_lock(&commit_mutex.commit_OLTP_OLAP_mutex);
  while ( commit_mutex.commit_OLAP_executing > 0 )
    pthread_cond_wait(&commit_mutex.commit_OLTP_cond, &commit_mutex.commit_OLTP_OLAP_mutex);
  commit_mutex.commit_OLTP_executing ++;
  pthread_mutex_unlock(&commit_mutex.commit_OLTP_OLAP_mutex);

  // send PREPARE TRANSACTION
  Send(task->server[0]->fd, task->client->packet, task->client->packetlen);
  RecvDataFromOne(task, 0);
  if ( task->server[0]->error == NOERROR ) {
    SendOthers(task);
    RecvOthers(task);
  } 

  for ( i = 0; i < sys->NumOLTPNode + sys->NumOLAPNode; i++ ) {
    if ( task->server[i]->error != NOERROR ) {
      found_error = i;
      error_server[i] = task->server[i]->error;
    } else error_server[i] = NOERROR;
  }

  if ( found_error == 0 ) { // the leader fails to PREPARE
    SendS_5ToFollowers(task);
    RecvS_5FromFollowers(task);
    //    SendRollbackToFollowers(task);
    //    RecvRollbackFromFollowers(task);
  } else if ( found_error > 0 ) {
    SendRollbackPrepared(task, error_server);   // ROLLBACK PREPARE
    RecvRollbackPrepared(task, error_server);   // ROLLBACK PREPARE
  }

  if ( found_error >= 0 ) {
    pthread_mutex_lock(&commit_mutex.commit_OLTP_OLAP_mutex);
    commit_mutex.commit_OLTP_executing --;
    if ( commit_mutex.commit_OLTP_executing == 0 )
      pthread_cond_broadcast(&commit_mutex.commit_OLAP_cond);
    pthread_mutex_unlock(&commit_mutex.commit_OLTP_OLAP_mutex);
  
    // release snapshot creation
    pthread_mutex_lock(&snapshot_commit_mutex.snapshot_commit_mutex);
    snapshot_commit_mutex.commit_executing --;
    if ( snapshot_commit_mutex.commit_executing == 0 )
      pthread_cond_broadcast(&snapshot_commit_mutex.snapshot_cond);
    pthread_mutex_unlock(&snapshot_commit_mutex.snapshot_commit_mutex);
    
    Send(task->client->fd, task->server[found_error]->packet, task->server[found_error]->packetlen); // send prepare NG
  } else
    Send(task->client->fd, task->server[0]->packet, task->server[0]->packetlen); // send prepare OK
  
  return;
}


void
ExecuteCommitSyncForOLTP(Task *task) {

  /*  memcpy(task->tmp_packet, task->client->packet, 31);
  snprintf(task->tmp_packet + 27, 5, "%d", task->thread_id);
  memcpy(task->tmp_packet + 31, task->client->packet + 31, task->client->packetlen - 31);
  memcpy(task->client->packet, task->tmp_packet, task->client->packetlen);
#ifdef PARSE_DEBUG
  printf("%p: COMMIT ID: %s\n", task, (char *)(task->client->packet + 27));
#endif
  */

  // block snapshot creation
  pthread_mutex_lock(&snapshot_commit_mutex.snapshot_commit_mutex);
  while ( snapshot_commit_mutex.snapshot_executing > 0 )
    pthread_cond_wait(&snapshot_commit_mutex.commit_cond, &snapshot_commit_mutex.snapshot_commit_mutex);
  snapshot_commit_mutex.commit_executing ++;
  pthread_mutex_unlock(&snapshot_commit_mutex.snapshot_commit_mutex);

  
  SendAll(task);
  RecvAll(task);
  
  // release commits for OLAP
  /*  pthread_mutex_lock(&commit_mutex.commit_OLTP_OLAP_mutex);
  commit_mutex.commit_OLTP_executing --;
  if ( commit_mutex.commit_OLTP_executing == 0 )
    pthread_cond_broadcast(&commit_mutex.commit_OLAP_cond);
    pthread_mutex_unlock(&commit_mutex.commit_OLTP_OLAP_mutex);*/

  // release snapshot creation
  pthread_mutex_lock(&snapshot_commit_mutex.snapshot_commit_mutex);
  snapshot_commit_mutex.commit_executing --;
  if ( snapshot_commit_mutex.commit_executing == 0 )
    pthread_cond_broadcast(&snapshot_commit_mutex.snapshot_cond);
  pthread_mutex_unlock(&snapshot_commit_mutex.snapshot_commit_mutex);

  Send(task->client->fd, task->server[0]->packet, task->server[0]->packetlen);

  return;
}

void
ExecuteSelect1Sync(Task *task) {
  int i;
  
  pthread_mutex_lock(&snapshot_commit_mutex.snapshot_commit_mutex);
  while ( snapshot_commit_mutex.commit_executing > 0 )
    pthread_cond_wait(&snapshot_commit_mutex.commit_cond, &snapshot_commit_mutex.snapshot_commit_mutex);
  snapshot_commit_mutex.snapshot_executing ++;
  pthread_mutex_unlock(&snapshot_commit_mutex.snapshot_commit_mutex);

  for (i = 0; i < sys->NumOLTPNode + sys->NumOLAPNode; i++) {
    SendSelect1(task, i);
  }
  RecvAll(task);

  pthread_mutex_lock(&snapshot_commit_mutex.snapshot_commit_mutex);
  snapshot_commit_mutex.snapshot_executing --;
  if ( snapshot_commit_mutex.snapshot_executing == 0 )
    pthread_cond_broadcast(&snapshot_commit_mutex.snapshot_cond);
  pthread_mutex_unlock(&snapshot_commit_mutex.snapshot_commit_mutex);

  return;
}

void
LeaderFollowerExecution(Task *task) {
  int i;
  bool sent = false;
  Send(task->server[0]->fd, task->client->packet, task->client->packetlen);
  RecvDataFromOne(task, 0);
  if ( task->server[0]->error == NOERROR ) {
    SendOthers(task);
    RecvOthers(task);
  }
  for (i = 0; i < sys->NumOLTPNode + sys->NumOLAPNode; i++) {
    if ( task->server[i]->error == SERROR ) {
      Send(task->client->fd, task->server[i]->packet, task->server[i]->packetlen);
      sent = true;
      break;
    }
  }
  if ( sent == false )
    Send(task->client->fd, task->server[0]->packet, task->server[0]->packetlen);

  return;
}


void
ExecuteOLAP_FOR_IDLE(Task *task) {

  switch ( task->qtype ) {
  case READ:
    ExecuteReadSyncForOLAP(task);
    task->status = OLAP_SNAPSHOT_CREATED;
    break;
  case WRITE:
  case ROLLBACK:
  case COMMIT:
  case BEGIN:
    SendAll(task);
    RecvAll(task);
    Send(task->client->fd, task->server[0]->packet, task->server[0]->packetlen);
    break;
  default:
    printf("%p cannot execute this OLAP query type: %s\n", task, (char *)(task->client->packet + 6));
    exit(EXIT_FAILURE);
    break;
  }

  return;  
}

void
ExecuteReadSyncForOLAP(Task *task) {
  
  // block commit execution
  /*  pthread_mutex_lock(&snapshot_commit_mutex.snapshot_commit_mutex);
  while ( snapshot_commit_mutex.commit_executing > 0 )
    pthread_cond_wait(&snapshot_commit_mutex.snapshot_cond, &snapshot_commit_mutex.snapshot_commit_mutex);
  snapshot_commit_mutex.snapshot_executing ++;
  pthread_mutex_unlock(&snapshot_commit_mutex.snapshot_commit_mutex);*/

  SendOneServer(task, task->mynode);
  RecvOneServer(task, task->mynode);

  /*  pthread_mutex_lock(&snapshot_commit_mutex.snapshot_commit_mutex);
  snapshot_commit_mutex.snapshot_executing --;
  if ( snapshot_commit_mutex.snapshot_executing == 0 )
    pthread_cond_broadcast(&snapshot_commit_mutex.commit_cond);
    pthread_mutex_unlock(&snapshot_commit_mutex.snapshot_commit_mutex);*/
  
  SendClient(task, task->mynode);

  return;
}

void
ExecuteOLAP_FOR_SNAPSHOT_CREATED(Task *task) {
  int tmp;
  switch ( task->qtype ) {
  case READ:
    SendOneServer(task, task->mynode);
    RecvOneServer(task, task->mynode);
    if ( ( tmp = CheckDangerousStructure(task) ) ) {
      pthread_mutex_lock(&read_dangerous_structure_counter_mutex);
      read_dangerous_structure_counter += tmp;
      printf("READ Conflict-in: %s\n", (char *)(task->client->packet + 6));
      pthread_mutex_unlock(&read_dangerous_structure_counter_mutex);
    }	
    Send(task->client->fd, task->server[task->mynode]->packet, task->server[task->mynode]->packetlen);
    break;
  case COMMIT:
    if ( ( tmp = CheckDangerousStructure(task) ) ) {
      pthread_mutex_lock(&commit_dangerous_structure_counter_mutex);
      commit_dangerous_structure_counter += tmp;
      printf("COMMIT Conflict-in: %s\n", (char *)(task->client->packet + 6));
      pthread_mutex_unlock(&commit_dangerous_structure_counter_mutex);	
    }
    ExecuteCommitSyncForOLAP(task);
    break;
  case WRITE:
    SendOneServer(task, task->mynode);
    RecvOneServer(task, task->mynode);
    Send(task->client->fd, task->server[task->mynode]->packet, task->server[task->mynode]->packetlen);
    break;
  case ROLLBACK:
  default:
    printf("%p cannot execute this OLAP query type: %s\n", task, (char *)(task->client->packet + 6));
    exit(EXIT_FAILURE);
  }
  return;
}

void
ExecuteCommitSyncForOLAP(Task *task) {
  /* int i; */
  /* ERR found_error = NOERROR; */

  // block snapshot creation
  /*  pthread_mutex_lock(&snapshot_commit_mutex.snapshot_commit_mutex);
  while ( snapshot_commit_mutex.snapshot_executing > 0 )
    pthread_cond_wait(&snapshot_commit_mutex.commit_cond, &snapshot_commit_mutex.snapshot_commit_mutex);
  snapshot_commit_mutex.commit_executing ++;
  pthread_mutex_unlock(&snapshot_commit_mutex.snapshot_commit_mutex);*/

  // block commits for OLAP
  /*  pthread_mutex_lock(&commit_mutex.commit_OLTP_OLAP_mutex);
  while ( commit_mutex.commit_OLTP_executing > 0 )
    pthread_cond_wait(&commit_mutex.commit_OLAP_cond, &commit_mutex.commit_OLTP_OLAP_mutex);
  commit_mutex.commit_OLAP_executing ++;
  pthread_mutex_unlock(&commit_mutex.commit_OLTP_OLAP_mutex);*/

  // send PREPARE TRANSACTION
  SendOneServer(task, task->mynode);
  RecvOneServer(task, task->mynode);

  // release commits for OLAP
  /*  pthread_mutex_lock(&commit_mutex.commit_OLTP_OLAP_mutex);
  commit_mutex.commit_OLAP_executing --;
  if ( commit_mutex.commit_OLAP_executing == 0 )
    pthread_cond_broadcast(&commit_mutex.commit_OLTP_cond);
    pthread_mutex_unlock(&commit_mutex.commit_OLTP_OLAP_mutex);*/

  // release snapshot creation
  /*  pthread_mutex_lock(&snapshot_commit_mutex.snapshot_commit_mutex);
  snapshot_commit_mutex.commit_executing --;
  if ( snapshot_commit_mutex.commit_executing == 0 )
    pthread_cond_broadcast(&snapshot_commit_mutex.snapshot_cond);
    pthread_mutex_unlock(&snapshot_commit_mutex.snapshot_commit_mutex);*/

  // send a response to the client
  SendClient(task, task->mynode);

  return;
}

void
ExecuteReadSyncForOLTP(Task *task) {

  pthread_mutex_lock(&snapshot_commit_mutex.snapshot_commit_mutex);
  while ( snapshot_commit_mutex.commit_executing > 0 )
    pthread_cond_wait(&snapshot_commit_mutex.snapshot_cond, &snapshot_commit_mutex.snapshot_commit_mutex);
  snapshot_commit_mutex.snapshot_executing ++;
  pthread_mutex_unlock(&snapshot_commit_mutex.snapshot_commit_mutex);

  SendAll(task);
  RecvAll(task);
  
   pthread_mutex_lock(&snapshot_commit_mutex.snapshot_commit_mutex);
  snapshot_commit_mutex.snapshot_executing --;
  if ( snapshot_commit_mutex.snapshot_executing == 0 )
    pthread_cond_broadcast(&snapshot_commit_mutex.commit_cond);
  pthread_mutex_unlock(&snapshot_commit_mutex.snapshot_commit_mutex);

  Send(task->client->fd, task->server[0]->packet, task->server[0]->packetlen);

  return;
}

int
CheckDangerousStructure(Task *task) {
  int i, tmp;
  if ( sys->NumOLAPNode != 0 )
    for ( tmp = 0, i = 0 ; i < sys->NumOLAPNode; i ++ )
      if ( (strncmp(task->server[i + 1]->packet + 20, "SERROR", 6) == 0 || strncmp(task->server[i + 1]->packet + 5, "SERROR", 6) == 0)
	   && !(strncmp(task->server[0]->packet + 20, "SERROR", 6) == 0 || strncmp(task->server[0]->packet + 5, "SERROR", 6) == 0)  ) {
	tmp = 1;
      }
  return tmp;
}
