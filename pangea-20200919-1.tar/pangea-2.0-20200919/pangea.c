/*
 * copyright (c) 2020 
 */

#include "pangea.h"

int
main(int argc, char **argv){

  InitSystem();
  InitDatabase();
  CreateBoss();
  CreateWorker();
  printf("*** Welcome, Pangea starts up successfully! ***\n");
  PrintStatistics();
  ThreadJoin();
  return 0;
}


void
InitSystem(void)
{
  int i;
  FILE *fp;
  char fname[] = "pangea.conf";
  char buf[1024];
  int chr, nodenum = 0;
  int index = 0;
  char *p;

  sys = (System *)Malloc(sizeof(System));
  memset(sys->com, 0, sizeof(char) * COMSZ);
  sys->clientport = (char *)Malloc(8 * sizeof(char));
  sys->serverport = (char *)Malloc(8 * sizeof(char));
  sys->opsport = "3335";
  sys->OLTPUser = (char *)Malloc(16 * sizeof(char));
  sys->OLAPUser = (char *)Malloc(16 * sizeof(char));
  sys->OLAPisolation = (char *)Malloc(32 * sizeof(char));
  pthread_mutex_init(&snapshot_commit_mutex.snapshot_commit_mutex, NULL);
  pthread_cond_init(&snapshot_commit_mutex.snapshot_cond, NULL);
  pthread_cond_init(&snapshot_commit_mutex.commit_cond, NULL);
  snapshot_commit_mutex.snapshot_executing = 0;
  snapshot_commit_mutex.commit_executing = 0;
  pthread_mutex_init(&snapshot_mutex.snapshot_OLTP_OLAP_mutex, NULL);
  pthread_cond_init(&snapshot_mutex.snapshot_OLTP_cond, NULL);
  pthread_cond_init(&snapshot_mutex.snapshot_OLAP_cond, NULL);
  snapshot_mutex.snapshot_OLTP_executing = 0;
  snapshot_mutex.snapshot_OLAP_executing = 0;
  pthread_mutex_init(&commit_mutex.commit_OLTP_OLAP_mutex, NULL);
  pthread_cond_init(&commit_mutex.commit_OLTP_cond, NULL);
  pthread_cond_init(&commit_mutex.commit_OLAP_cond, NULL);
  commit_mutex.commit_OLTP_executing = 0;
  commit_mutex.commit_OLAP_executing = 0;
  pthread_mutex_init(&read_dangerous_structure_counter_mutex, NULL);
  read_dangerous_structure_counter = 0;
  pthread_mutex_init(&write_dangerous_structure_counter_mutex, NULL);
  write_dangerous_structure_counter = 0;
  pthread_mutex_init(&commit_dangerous_structure_counter_mutex, NULL);
  commit_dangerous_structure_counter = 0;

  
  for (i = 0; i < MAX_NUM_NODE; i++) {
    sys->host[i].name = (char *)Malloc(MAX_NODE_NAME_LENGTH * sizeof(char));
    sys->host[i].port = "5432";
  }
  
  fp = fopen(fname, "r");
  if(fp == NULL) {
    printf("%s file not open!\n", fname);
    return;
  }

  while((chr = fgetc(fp)) != EOF) {
    if (chr == '\n'){
      buf[index] = '\0';
      
      if (strncmp(buf, "host", 4) == 0 ){
	for (p = &buf[4]; *p == ' '|| *p == '\t'; p++);
	strncpy(sys->host[nodenum++].name, p, 15);
      }
      else if (strncmp(buf, "num_of_OLTP_node", 16) == 0 ){
	for (p = &buf[16]; *p == ' '|| *p == '\t'; p++);
	sys->NumOLTPNode = atoi(p);
      }
      else if (strncmp(buf, "num_of_OLTP_thread", 18) == 0 ){
	for (p = &buf[18]; *p == ' '|| *p == '\t'; p++);
	sys->NumOLTPThread = atoi(p);
      }
      else if (strncmp(buf, "num_of_OLAP_node", 16) == 0 ){
	for (p = &buf[16]; *p == ' '|| *p == '\t'; p++);
	sys->NumOLAPNode = atoi(p);
      }
      else if (strncmp(buf, "num_of_OLAP_thread", 18) == 0 ){
	for (p = &buf[18]; *p == ' '|| *p == '\t'; p++);
	sys->NumOLAPThread = atoi(p);
      }
      else if (strncmp(buf, "clientport", 10) == 0 ){
	for (p = &buf[10]; *p == ' '|| *p == '\t'; p++);
	strncpy(sys->clientport, p, 4);	
      }
      else if (strncmp(buf, "serverport", 10) == 0 ){
	for (p = &buf[10]; *p == ' '|| *p == '\t'; p++);
	strncpy(sys->serverport, p, 4);	
      }
      else if ( strncmp(buf, "OLTPuser", 8) == 0 ) {
	for (p = &buf[10]; *p == ' '|| *p == '\t'; p++);
	strcpy(sys->OLTPUser, p);		
      }
      else if ( strncmp(buf, "OLAPuser", 8) == 0 ) {
	for (p = &buf[10]; *p == ' '|| *p == '\t'; p++);
	strcpy(sys->OLAPUser, p);		
      }
      else if ( strncmp(buf, "OLAPisolation", 13) == 0 ) {
	for (p = &buf[15]; *p == ' '|| *p == '\t'; p++);
	strcpy(sys->OLAPisolation, p);
      }
      index = 0;
    }
    else
      buf[index++] = chr;
  }

  fclose(fp);

  //  sys->host = (Host *)Malloc( (sys->NumOLTPNode + sys->NumOLAPNode) * sizeof(Host));
  sys->InitPacket.InitFlag = SET_INVALID;
  sys->InitPacket.InitFlagMutex = (pthread_mutex_t *)malloc(sizeof(pthread_mutex_t));
  pthread_mutex_init(sys->InitPacket.InitFlagMutex, NULL);
  sys->InitPacket.InitFlagCond = (pthread_cond_t *)malloc(sizeof(pthread_cond_t));
  pthread_cond_init(sys->InitPacket.InitFlagCond, NULL);
  sys->InitPacket.startup_packet = (char *)Malloc(QUERYBUFSZ);
  sys->InitPacket.startup_packetlen = 0;
  sys->InitPacket.setup1_packet = (char *)Malloc(QUERYBUFSZ);
  sys->InitPacket.setup1_packetlen = 0;
  sys->InitPacket.setup2_packet = (char *)Malloc(QUERYBUFSZ);
  sys->InitPacket.setup2_packetlen = 0;
  
  for (i = 0; i < (sys->NumOLTPNode + sys->NumOLAPNode); i++) {
    sys->host[i].name = (char *)Malloc(NAMELENGTH * sizeof(char));
    sys->host[i].port = "5432";
  }

  return;
}

void
InitDatabase(void) {
  int i, j;
  FILE *fp;
  char fname[] = "pangea.conf";
  char buf[1024];
  int chr;
  int index = 0;
  int counter = 0;
  char *p;
  
  database = (DATABASE *)Malloc(MAX_DATABASE * sizeof(DATABASE));
  for (i = 0; i < MAX_DATABASE; i++) {
    database[i].database_name = (char *)Malloc(NAMELENGTH * sizeof(char));
    database[i].server.server_name = (char **)Malloc((sys->NumOLTPNode + sys->NumOLAPNode) * sizeof(char *));
    database[i].server.server_port = (char *)Malloc(8 * sizeof(char));

    for (j = 0; j < (sys->NumOLTPNode + sys->NumOLAPNode); j++) {
      database[i].server.server_name[j] = (char *)Malloc(NAMELENGTH * sizeof(char));
      database[i].server.server_name[j][0] = '\0';
    }
    database[i].wids = (pthread_t *)Malloc( ( sys->NumOLTPThread + sys->NumOLAPThread ) * sizeof(pthread_t));

    /* wait queue */
    database[i].wait_queue.len = 0;
    database[i].wait_queue.head.prev = &database[i].wait_queue.head;
    database[i].wait_queue.head.next = &database[i].wait_queue.head;
    database[i].wait_queue.queue_mutex = (pthread_mutex_t *)Malloc(sizeof(pthread_mutex_t));
    pthread_mutex_init(database[i].wait_queue.queue_mutex, NULL);
    database[i].wait_queue.queue_cond = (pthread_cond_t *)Malloc(sizeof(pthread_cond_t));
    pthread_cond_init(database[i].wait_queue.queue_cond, NULL);
    /* run queue */
    database[i].run_queue.len = 0;
    database[i].run_queue.head.prev = &database[i].run_queue.head;
    database[i].run_queue.head.next = &database[i].run_queue.head;;
    database[i].run_queue.queue_mutex = (pthread_mutex_t *)Malloc(sizeof(pthread_mutex_t));
    pthread_mutex_init(database[i].run_queue.queue_mutex, NULL);
    database[i].run_queue.queue_cond = (pthread_cond_t *)Malloc(sizeof(pthread_cond_t));
    pthread_cond_init(database[i].run_queue.queue_cond, NULL);

  } /* for i loop end */
	
  fp = fopen(fname, "r");
  if(fp == NULL) {
    printf("%s file not open!\n", fname);
    return;
  }

  counter = 0;
  while((chr = fgetc(fp)) != EOF) {
    if (chr == '\n'){
      buf[index] = '\0';

      if (strncmp(buf, "database_name", 13) == 0 ){
	for (p = &buf[11]; *p == ' '|| *p == '\t'; p++);
	strncpy(database[0].database_name, p, 6);
      }
      else if (strncmp(buf, "server_name", 11) == 0 ){
	for (p = &buf[11]; *p == ' '|| *p == '\t'; p++);
	strncpy(database[0].server.server_name[counter++], p, 15);
      }
      else if (strncmp(buf, "serverport", 10) == 0 ){
	for (p = &buf[11]; *p == ' '|| *p == '\t'; p++);
	strncpy(database[0].server.server_port, p, 4);
	strncpy(database[0].server.server_port+4, "\0", 1);
      }
      
      index = 0;
    }
    else
      buf[index++] = chr;
  }
  database[0].server.numactsrv = counter;
  
  fclose(fp);

  return;
}

void
CreateWorker(void) {
  int errnum;
  int *tid; /* database id */ /* we cannnot change this tid array to one tid variable */
  int i, j;

  tid = (int *)Malloc(MAX_DATABASE * sizeof(int));
  for (i = 0; i < MAX_DATABASE; i++) {
    tid[i] = i;
    for (j = 0; j < sys->NumOLTPThread + sys->NumOLAPThread; j++)
      if ( ( errnum = pthread_create(&database[i].wids[j], NULL, worker, (void *)&tid[i]) ) != 0 ) {
	printf("pthread_create() in CreateWorker: %s\n", strerror(errnum));
	exit(EXIT_FAILURE);
      }
      else
	printf("created worker\n");
  }
  return;	
}

void
ThreadJoin(void) {
  int i, j;
  for (i = 0; i < MAX_DATABASE; i++) {
    for (j = 0; j < sys->NumOLTPThread + sys->NumOLAPThread; j++) {
      pthread_join(database[i].wids[j], NULL);
      printf("joined worker\n");
    }
  }

  return;
}

void
CreateBoss(void) {
  int errnum;

  if ( ( errnum = pthread_create(&sys->bid, NULL, Boss, NULL ) ) != 0 ) {
    printf("pthread_create() in CreateBoss: %s\n", strerror(errnum));
    exit(EXIT_FAILURE);
  }
  else
    printf("created boss!\n");
  return;
}

void
PrintStatistics(void) {
  struct timeval tv;
  for ( ; ; ) {
    tv.tv_sec = 20;
    tv.tv_usec = 0;
    select(0, NULL, NULL, NULL, &tv);
    pthread_mutex_lock(&read_dangerous_structure_counter_mutex);
    printf("read_dangerous_structure_counter: %d\n", read_dangerous_structure_counter);
    pthread_mutex_unlock(&read_dangerous_structure_counter_mutex);
    pthread_mutex_lock(&write_dangerous_structure_counter_mutex);
    printf("write_dangerous_structure_counter: %d\n", write_dangerous_structure_counter);
    pthread_mutex_unlock(&write_dangerous_structure_counter_mutex);
    pthread_mutex_lock(&commit_dangerous_structure_counter_mutex);
    printf("commit_dangerous_structure_counter: %d\n", commit_dangerous_structure_counter);
    pthread_mutex_unlock(&commit_dangerous_structure_counter_mutex);
  }
  
  return;
}
