/*
 * copyright (c) 2020 
 */

/* prototypes */

void *Boss(void *);
Task *CreateTask(int, int *);
void PutTaskToWaitQueue(Task *);
void Reselection(Task *, char *);
void CheckUser(Task *);
void GetSelect1(Task *);
void GetPrepare(Task *);
void GetCommitPrepared(Task *);
void GetCommitSuccess1(Task *);
void GetCommitSuccess2(Task *);
void GetCommitError1(Task *);
void GetCommitError2(Task *);
void GetRollback1(Task *);
void GetRollback2(Task *);
void GetRollbackPrepared(Task *);
void SelectMyNode(Task *);
void GetS_5_P(Task *);
void GetS_5_B(Task *);
extern void GeneralSelection(Task *);
extern System *sys;
extern DATABASE *database;
