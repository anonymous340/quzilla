#define QUIT -1
#define ADD 1
#define CREATE 2
#define ACTIVE 3
#define STANDBY 4
#define SHUTDOWN 5
#define SUSPEND 6
#define INFO 8
#define HELP 9
#define OFFLOAD 10
#define SYNC 30
#define MIG 31
#define DEL 32
#define STOP 50
#define GO 51

#define COMBUFSZ 128

typedef struct {
	char statement[COMBUFSZ];
	int len;
	int cur;
	int pangea_fd;
	int operator_fd;
} Command;
