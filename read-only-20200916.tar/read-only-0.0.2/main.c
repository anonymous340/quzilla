/*
 * Copyright (c) 2020-2020 
 */

#include "main.h"

int
main(int argc, char **argv)
{
  int i, errnum;
  pthread_t **tids;
  double log(), drand48(), atof();
  int sum_t1_commit_time, sum_t1_abort_time, sum_t1_commit_counter, sum_t1_abort_counter;
  
  sum_t1_commit_time = sum_t1_abort_time = sum_t1_commit_counter = sum_t1_abort_counter = 0;
  
  if (argc != 6 ){
    printf("./main arrival_rate num_of_transaction num_of_goods seed inserted_data \n");
    exit(1);
  }
  arrival_rate = atof(argv[1]);
  num_of_transaction = atoi(argv[2]);
  num_of_goods = atoi(argv[3]);
  srand48(atoi(argv[4]));
  inserted_data = atoi(argv[5]);
  
  tids = (pthread_t **)malloc(NUMTXN * sizeof(pthread_t *));
  for ( i = 0; i < NUMTXN; i ++ )
    tids[i] = (pthread_t *)malloc(num_of_goods * sizeof(pthread_t));

  t1_commit_time = (int *)malloc(num_of_goods * sizeof(int));
  t1_abort_time = (int *)malloc(num_of_goods * sizeof(int));
  t1_commit_counter = (int *)malloc(num_of_goods * sizeof(int));
  t1_abort_counter = (int *)malloc(num_of_goods * sizeof(int));

  thread_id = 0;
  thread_id_mutex = (pthread_mutex_t *)malloc(sizeof(pthread_mutex_t));
  pthread_mutex_init(thread_id_mutex, NULL);

  pthread_mutex_init(&tran_lock, NULL);
  pthread_cond_init(&tran_cond, NULL);
  tran_counter = 0;
  
  for ( i = 0; i < num_of_goods; i ++ ) {
    errnum = pthread_create(&tids[0][i], NULL, T3, NULL );
    errnum = pthread_create(&tids[1][i], NULL, T2, NULL );
    errnum = pthread_create(&tids[2][i], NULL, T1, NULL );
  }

  for ( i = 0; i < num_of_goods; i++ ) {
    pthread_join(tids[0][i], NULL);
    pthread_join(tids[1][i], NULL);
    pthread_join(tids[2][i], NULL);
  }

  for ( i = 0; i < num_of_goods; i ++ ) {
    sum_t1_commit_time += t1_commit_time[i];
    sum_t1_abort_time += t1_abort_time[i];
    sum_t1_commit_counter += t1_commit_counter[i];
    sum_t1_abort_counter += t1_abort_counter[i];
  }    
    
  printf("T1_throuput: %f [tps]\n", 1000000 * (double)num_of_goods * (double)num_of_transaction / (double)sum_t1_commit_time);
  printf("T1_commit_time: %f [us]\n", (double)sum_t1_commit_time/(double)sum_t1_commit_counter);
  if ( sum_t1_abort_counter != 0 )
    printf("T1_abort_time: %f [us]\n", (double)sum_t1_abort_time/(double)sum_t1_abort_counter);
  else
    printf("T1_abort_time: N/A [us]\n");
  printf("T1_commit_counter: %d \n", sum_t1_commit_counter);
  printf("T1_abort_counter: %d \n", sum_t1_abort_counter);
  
  return 0;
}
