/*
 * Copyright (c) 2020-2020 
 */

#include "T3.h"

void *
T3(void *arg)
{
  const char *conninfo;
  PGconn *conn;
  PGresult *res;
  int i, x, my_thread_id;
  struct timeval tv, start_tv, end_tv;
  
  char s[NUM_OF_STATEMENT] = {'\0'};

  pthread_mutex_lock(thread_id_mutex);
  my_thread_id =  thread_id ++;
  pthread_mutex_unlock(thread_id_mutex);

  conninfo = "hostaddr=172.31.53.8 port=3333 dbname=testdb user=ubuntu";

  arrival_rate = 1;
  num_of_transaction = 1;
  num_of_users = 1;
  
  conn = PQconnectdb(conninfo);

  if ( PQstatus(conn) != CONNECTION_OK )
    printf("Connection tpcw to database failed: %s", PQerrorMessage(conn));

  for ( i = 0; i < num_of_transaction; i++) {
    gettimeofday(&start_tv, NULL);
  retry:
    tv.tv_sec = 0;
    tv.tv_usec = (long) 1000000 * (x = -1 * log(drand48()) / arrival_rate);
    select(0, NULL, NULL, NULL, &tv);

    res = PQexec(conn, "/* OLTP */ BEGIN");
    if ( PQresultStatus(res) != PGRES_COMMAND_OK ) {
      printf("BEGIN command failed: %s", PQerrorMessage(conn));
      PQclear(res);
      goto retry;
    }
    PQclear(res);

    res = PQexec(conn, "SELECT * FROM current_batch");
    if ( PQresultStatus(res) != PGRES_TUPLES_OK ) {
      printf("SELECT command failed: %s", PQerrorMessage(conn));
      PQclear(res);
      exit(1);
    }
    x = atoi(PQgetvalue(res, 0, 0));
    PQclear(res);

    snprintf(s, NUM_OF_STATEMENT, "UPDATE current_batch SET x=%d WHERE x = %d", x+1, x);
    printf("T3 new current batch:%d\n", x+1);
#ifdef DEBUG
    printf("%s\n", s);
#endif

    res = PQexec(conn, s);
    if ( PQresultStatus(res) != PGRES_COMMAND_OK ) {
      printf("UPDATE command failed\n");
      PQclear(res);
      printf("T3 UPDATE ROLLBACKing\n");
      res = PQexec(conn, "ROLLBACK");
      if ( PQresultStatus(res) != PGRES_COMMAND_OK ) {
	printf("T3 UPDATE ROLLBACK failed\n");
	exit(1);
      }
      printf("T3 UPDATE ROLLBACKed\n");
      //      t3_abort_counter[my_thread_id] ++;
      PQclear(res);
      goto retry;
    }
    PQclear(res);

    res = PQexec(conn, "PREPARE TRANSACTION 'T3-0'");
    if ( PQresultStatus(res) != PGRES_COMMAND_OK ) {
	printf("PREPARE of T3 failed: %s", PQerrorMessage(conn));
	PQclear(res);
	printf("T3 PREPARE ROLLBACKing\n");
	//	res = PQexec(conn, "ROLLBACK");
	if ( PQresultStatus(res) != PGRES_COMMAND_OK ) {
	  printf("T3 PREPRE ROLLBACK failed\n");
	}
	printf("T3 PREPARE ROLLBACKed\n");
	PQclear(res);
	goto retry;
    }
    PQclear(res);

    snprintf(s, NUM_OF_STATEMENT, "COMMIT PREPARED 'T3-0'");
    //    res = PQexec(conn, "COMMIT");
    res = PQexec(conn, s);
    printf("T3 end\n");
    pthread_mutex_lock(&tran_lock);
    tran_counter++;
    pthread_cond_signal(&tran_cond);
    pthread_mutex_unlock(&tran_lock);

    if ( PQresultStatus(res) != PGRES_COMMAND_OK ) {
      //      printf("COMMIT of T3 failed: %s", PQerrorMessage(conn));
      printf("COMMIT of T3 failed\n");
      PQclear(res);
      printf("T3 ROLLBACKing\n");
      res = PQexec(conn, "ROLLBACK");
      if ( PQresultStatus(res) != PGRES_COMMAND_OK ) {
	printf("T3 ROLLBACK failed\n");
      }
      printf("T3 ROLLBACKed\n");
      PQclear(res);
      goto retry;
    }
    //      printf("T3 ABORTed\n");
    PQclear(res);
    gettimeofday(&end_tv, NULL);
    //    t3_commit_time[my_thread_id] += (1000000 * (end_tv.tv_sec - start_tv.tv_sec ) + (end_tv.tv_usec - start_tv.tv_usec ));
    //    t3_commit_counter[my_thread_id] ++;
  } // while end

  PQfinish(conn);

  pthread_exit(NULL);

  
}
