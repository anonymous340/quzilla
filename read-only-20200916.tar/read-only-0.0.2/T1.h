/*
 * Copyright (c) 2020-2020 
 */

#include <stdio.h>
#include <stdlib.h>
#include <libpq-fe.h>
#include <pthread.h>
#include <unistd.h>
#include <stdbool.h>
#include <math.h>
#include <sys/time.h>
#include "main.h"

#define NUM_OF_STATEMENT 256

void *T1(void *);

double mean_sleep_time;
double arrival_rate;
int num_of_transaction;
int num_of_users;

int *t1_commit_time, *t1_abort_time;
int *t1_commit_counter, *t1_abort_counter;

int thread_id;
pthread_mutex_t *thread_id_mutex;
