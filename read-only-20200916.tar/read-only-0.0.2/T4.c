/*
 * Copyright (c) 2020-2020 
 */

#include "T4.h"

int
main(int argc, char **argv) {
  int i;
  pthread_t *tids;
  double log(), drand48(), atof();
  int sum_t2_commit_time, sum_t2_abort_time, sum_t2_commit_counter, sum_t2_abort_counter;
  int sum_t2_insert_abort_counter, sum_t2_select_abort_counter, sum_t2_prepare_abort_counter, sum_t2_commit_abort_counter;
  
  sum_t2_commit_time = sum_t2_abort_time = sum_t2_commit_counter = sum_t2_abort_counter = 0;
  sum_t2_insert_abort_counter = sum_t2_select_abort_counter = sum_t2_prepare_abort_counter = sum_t2_commit_abort_counter = 0;
  
  if (argc != 5 ){
    printf("./T4 arrival_rate num_of_transaction num_of_users seed\n");
    exit(1);
  }

  arrival_rate = atof(argv[1]);
  num_of_transaction = atoi(argv[2]);
  num_of_users = atoi(argv[3]);
  srand48(atoi(argv[4]));
  
  tids = (pthread_t *)malloc(num_of_users * sizeof(pthread_t));

  t2_commit_time = (int *)malloc(num_of_users * sizeof(int));
  t2_abort_time = (int *)malloc(num_of_users * sizeof(int));
  t2_commit_counter = (int *)malloc(num_of_users * sizeof(int));
  t2_abort_counter = (int *)malloc(num_of_users * sizeof(int));

  t2_insert_abort_counter = (int *)malloc(num_of_users * sizeof(int));
  t2_select_abort_counter = (int *)malloc(num_of_users * sizeof(int));
  t2_prepare_abort_counter = (int *)malloc(num_of_users * sizeof(int));
  t2_commit_abort_counter = (int *)malloc(num_of_users * sizeof(int));
  
  thread_id = 0;
  thread_id_mutex = (pthread_mutex_t *)malloc(sizeof(pthread_mutex_t));
  pthread_mutex_init(thread_id_mutex, NULL);
  
  for ( i = 0; i < num_of_users; i ++ )
    pthread_create(&tids[i], NULL, T4, NULL );

  for ( i = 0; i < num_of_users; i++ )
    pthread_join(tids[i], NULL);

  for ( i = 0; i < num_of_users; i ++ ) {
    sum_t2_commit_time += t2_commit_time[i];
    sum_t2_abort_time += t2_abort_time[i];
    sum_t2_commit_counter += t2_commit_counter[i];
    sum_t2_abort_counter += t2_abort_counter[i];
    sum_t2_insert_abort_counter += t2_insert_abort_counter[i];
    sum_t2_select_abort_counter += t2_select_abort_counter[i];
    sum_t2_prepare_abort_counter += t2_prepare_abort_counter[i];
    sum_t2_commit_abort_counter += t2_commit_abort_counter[i];
  }    
    
  printf("T4_throuput: %f [tps]\n", 1000000 * (double)num_of_users * (double)num_of_transaction / (double)sum_t2_commit_time);
  printf("T4_commit_time: %f [us]\n", (double)sum_t2_commit_time/(double)sum_t2_commit_counter);
  if ( sum_t2_abort_counter != 0 )
    printf("T4_abort_time: %f [us]\n", (double)sum_t2_abort_time/(double)sum_t2_abort_counter);
  else
    printf("T4_abort_time: N/A [us]\n");
  printf("T4_commit_counter: %d \n", sum_t2_commit_counter);
  printf("T4_abort_counter: %d \n", sum_t2_abort_counter);

  printf("T4_insert_abort_counter: %d \n", sum_t2_insert_abort_counter);
  printf("T4_select_abort_counter: %d \n", sum_t2_select_abort_counter);
  printf("T4_prepare_abort_counter: %d \n", sum_t2_prepare_abort_counter);
  printf("T4_commit_abort_counter: %d \n", sum_t2_commit_abort_counter);
  
  
  return 0;
}

void *
T4(void *arg)
{
  const char *conninfo;
  PGconn *conn;
  PGresult *res;
  int i, x, my_thread_id;
  struct timeval tv, start_tv, end_tv;
  char s[NUM_OF_STATEMENT] = {'\0'};

  pthread_mutex_lock(thread_id_mutex);
  my_thread_id =  thread_id ++;
  pthread_mutex_unlock(thread_id_mutex);
  
  //  conninfo = "hostaddr=192.168.100.107 dbname=tpcw user=pgsql password=iseebipai";
  conninfo = "hostaddr=192.168.62.229 port=3333 dbname=testdb user=mishima";
  //  conninfo = "dbname=testdb user=test password=abc";
  //select count(*) from receipts  
  conn = PQconnectdb(conninfo);

  if ( PQstatus(conn) != CONNECTION_OK )
    printf("Connection tpcw to database failed: %s", PQerrorMessage(conn));

  for ( i = 0; i < num_of_transaction; i++) {
    gettimeofday(&start_tv, NULL);
  retry:
    tv.tv_sec = 0;
    tv.tv_usec = (long) 1000000 * (x = -1 * log(drand48()) / arrival_rate);
    select(0, NULL, NULL, NULL, &tv);
  
    res = PQexec(conn, "BEGIN");
#ifdef DEBUG
    printf("T4:BEGIN\n");
#endif
    if ( PQresultStatus(res) != PGRES_COMMAND_OK ) {
      printf("BEGIN command failed: %s", PQerrorMessage(conn));
      PQclear(res);
      exit(1);
    }
    PQclear(res);

    res = PQexec(conn, "SELECT * FROM current_batch");
#ifdef DEBUG
    printf("T4: SELECT * FROM current_batch\n");
#endif
    if ( PQresultStatus(res) != PGRES_TUPLES_OK ) {
      printf("T4: SELECT command failed: %s", PQerrorMessage(conn));
      t2_abort_counter[my_thread_id] ++;
      PQclear(res);
      exit(1);
    }
    x = atoi(PQgetvalue(res, 0, 0));
    PQclear(res);
    
    snprintf(s, NUM_OF_STATEMENT, "INSERT INTO receipts VALUES (%d, 3)", x);

#ifdef DEBUG
    printf("T4:%s\n", s);
#endif
    res = PQexec(conn, s);
    if ( PQresultStatus(res) != PGRES_COMMAND_OK ) {
      printf("T4:INSERT command failed: %s", PQerrorMessage(conn));
      t2_insert_abort_counter[my_thread_id] ++;
      //      printf("T4 ROLLBACKing\n");
      res = PQexec(conn, "ROLLBACK");
      if ( PQresultStatus(res) != PGRES_COMMAND_OK ) {
	printf("T4 INSERT ROLLBACK failed\n");
      }
      //      printf("T4 ROLLBACKed\n");
      goto retry;
    }
    PQclear(res);

    res = PQexec(conn, "select count(*) from receipts");
    if ( PQresultStatus(res) != PGRES_TUPLES_OK ) {
      printf("T4: SELECT command failed: %s", PQerrorMessage(conn));
      t2_select_abort_counter[my_thread_id] ++;
      res = PQexec(conn, "ROLLBACK");
      if ( PQresultStatus(res) != PGRES_COMMAND_OK ) {
	printf("T4 SELECT ROLLBACK failed\n");
      }
      goto retry;
    }

    
#ifdef DEBUG
    printf("T4:PREPARE TRANSACTION 'T4-0'\n");
#endif
    res = PQexec(conn, "PREPARE TRANSACTION 'T4-0'");
    if ( PQresultStatus(res) != PGRES_COMMAND_OK ) {
	printf("PREPARE of T4 failed: %s", PQerrorMessage(conn));
	//	printf("T4 ROLLBACKing\n");
	//	res = PQexec(conn, "ROLLBACK");
	if ( PQresultStatus(res) != PGRES_COMMAND_OK ) {
	  printf("T4 PREPARE ROLLBACK failed\n");
	}
	//	printf("T4 ROLLBACKEDed\n");
	t2_prepare_abort_counter[my_thread_id] ++;
	PQclear(res);
	goto retry;
    }
    PQclear(res);

    snprintf(s, NUM_OF_STATEMENT, "COMMIT PREPARED 'T4-0'");
    res = PQexec(conn, "COMMIT PREPARED 'T4-0'");
#ifdef DEBUG
    printf("T4:COMMIT PREPARED 'T4-0'\n");
#endif
    if ( PQresultStatus(res) != PGRES_COMMAND_OK ) {
	printf("COMMIT of T4 failed: %s", PQerrorMessage(conn));
	printf("T4 ABORTing\n");
	res = PQexec(conn, "ABORT");
	if ( PQresultStatus(res) != PGRES_COMMAND_OK ) {
	  printf("T4 ABORT failed\n");
	}
	printf("T4 ABORTed\n");
	t2_commit_abort_counter[my_thread_id] ++;
	goto retry;
    }
    PQclear(res);
    gettimeofday(&end_tv, NULL);
    t2_commit_time[my_thread_id] += (1000000 * (end_tv.tv_sec - start_tv.tv_sec ) + (end_tv.tv_usec - start_tv.tv_usec ));
    t2_commit_counter[my_thread_id] ++;

  } // while end

  PQfinish(conn);

  pthread_exit(NULL);
}
