/*
 * Copyright (c) 2020-2020 
 */

#include "T2.h"

void *
T2(void *arg)
{
  const char *conninfo;
  PGconn *conn;
  PGresult *res;
  int i, x, my_thread_id;
  struct timeval tv, start_tv, end_tv;
  char s[NUM_OF_STATEMENT] = {'\0'};

  pthread_mutex_lock(thread_id_mutex);
  my_thread_id =  thread_id ++;
  pthread_mutex_unlock(thread_id_mutex);
  
  arrival_rate = 1;
  num_of_transaction = 1;
  num_of_users = 1;
  
  conninfo = "hostaddr=172.31.53.8 port=3333 dbname=testdb user=ubuntu";
    //  conninfo = "dbname=testdb user=test password=abc";
  conn = PQconnectdb(conninfo);

  if ( PQstatus(conn) != CONNECTION_OK )
    printf("Connection tpcw to database failed: %s", PQerrorMessage(conn));

  for ( i = 0; i < num_of_transaction; i++) {
    gettimeofday(&start_tv, NULL);
  retry:
    tv.tv_sec = 0;
    tv.tv_usec = (long) 1000000 * (x = -1 * log(drand48()) / arrival_rate);
    select(0, NULL, NULL, NULL, &tv);
  
    res = PQexec(conn, "/* OLTP */ BEGIN");
#ifdef DEBUG
    printf("T2:BEGIN\n");
#endif
    if ( PQresultStatus(res) != PGRES_COMMAND_OK ) {
      printf("BEGIN command failed: %s", PQerrorMessage(conn));
      PQclear(res);
      exit(1);
    }
    PQclear(res);

    res = PQexec(conn, "SELECT * FROM current_batch");
#ifdef DEBUG
    printf("T2: SELECT * FROM current_batch\n");
#endif
    if ( PQresultStatus(res) != PGRES_TUPLES_OK ) {
      printf("T2: SELECT command failed: %s", PQerrorMessage(conn));
      //      t2_abort_counter[my_thread_id] ++;
      PQclear(res);
      exit(1);
    }
    x = atoi(PQgetvalue(res, 0, 0));
    PQclear(res);
    
    snprintf(s, NUM_OF_STATEMENT, "INSERT INTO receipts VALUES (%d, %d)", x, inserted_data);

#ifdef DEBUG
    printf("T2:%s\n", s);
#endif
    res = PQexec(conn, s);
    if ( PQresultStatus(res) != PGRES_COMMAND_OK ) {
      printf("T2:INSERT command failed: %s", PQerrorMessage(conn));
      //      t2_insert_abort_counter[my_thread_id] ++;
      res = PQexec(conn, "ROLLBACK");
      if ( PQresultStatus(res) != PGRES_COMMAND_OK ) {
	printf("T2 INSERT ROLLBACK failed\n");
      }
      goto retry;
    }
    PQclear(res);
    
#ifdef DEBUG
    printf("T2:PREPARE TRANSACTION 'T2-0'\n");
#endif
    res = PQexec(conn, "PREPARE TRANSACTION 'T2-0'");
    if ( PQresultStatus(res) != PGRES_COMMAND_OK ) {
	printf("PREPARE of T2 failed: %s", PQerrorMessage(conn));
	//	t2_prepare_abort_counter[my_thread_id] ++;
	PQclear(res);
	goto retry;
    }
    PQclear(res);

    snprintf(s, NUM_OF_STATEMENT, "COMMIT PREPARED 'T2-0'");
    res = PQexec(conn, "COMMIT PREPARED 'T2-0'");
#ifdef DEBUG
    printf("T2:COMMIT PREPARED 'T2-0'\n");
#endif
    if ( PQresultStatus(res) != PGRES_COMMAND_OK ) {
	printf("COMMIT of T2 failed: %s", PQerrorMessage(conn));
	printf("T2 ABORTing\n");
	res = PQexec(conn, "ABORT");
	if ( PQresultStatus(res) != PGRES_COMMAND_OK ) {
	  printf("T2 ABORT failed\n");
	}
	printf("T2 ABORTed\n");
	//	t2_commit_abort_counter[my_thread_id] ++;
	goto retry;
    }
    PQclear(res);
    gettimeofday(&end_tv, NULL);
    //    t2_commit_time[my_thread_id] += (1000000 * (end_tv.tv_sec - start_tv.tv_sec ) + (end_tv.tv_usec - start_tv.tv_usec ));
    //    t2_commit_counter[my_thread_id] ++;

  } // while end

  PQfinish(conn);

  pthread_exit(NULL);
}
