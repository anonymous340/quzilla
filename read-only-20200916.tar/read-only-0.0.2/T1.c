/*
 * Copyright (c) 2020-2020 
 */

#include "T1.h"

void *
T1(void *arg)
{
  const char *conninfo;
  struct timeval tv, start_tv, end_tv;
  PGconn *conn;
  PGresult *res;
  int i, x, y, my_thread_id;
  char s[NUM_OF_STATEMENT] = {'\0'};

  pthread_mutex_lock(thread_id_mutex);
  my_thread_id =  thread_id ++;
  pthread_mutex_unlock(thread_id_mutex);
  
  t1_commit_time[my_thread_id] = t1_abort_time[my_thread_id] = 0;
  t1_commit_counter[my_thread_id] = t1_abort_counter[my_thread_id] = 0;
  //  conninfo = "dbname=testdb user=test password=abc";
  conninfo = "hostaddr=172.31.53.8 port=3333 dbname=testdb user=ubuntu";

  arrival_rate = 1;
  num_of_transaction = 1;
  num_of_users = 1;
  
  conn = PQconnectdb(conninfo);
  if ( PQstatus(conn) != CONNECTION_OK )
    printf("Connection tpcw to database failed: %s", PQerrorMessage(conn));

  for ( i = 0; i < num_of_transaction; i++) {
    tv.tv_sec = 0;
    tv.tv_usec = (long) 1000000 * (x = -1 * log(drand48()) / arrival_rate);
    select(0, NULL, NULL, NULL, &tv);

    gettimeofday(&start_tv, NULL);
  retry:
    pthread_mutex_lock(&tran_lock);
    while ( tran_counter == 0 )
      pthread_cond_wait(&tran_cond, &tran_lock);
    pthread_mutex_unlock(&tran_lock);
    printf("T1 start\n");

    res = PQexec(conn, "/* OLAP */ BEGIN");
    if ( PQresultStatus(res) != PGRES_COMMAND_OK ) {
      printf("BEGIN command failed: %s", PQerrorMessage(conn));
      PQclear(res);
      exit(1);
    }
    PQclear(res);

    
    res = PQexec(conn, "SELECT * FROM current_batch");
    if ( PQresultStatus(res) != PGRES_TUPLES_OK ) {
      printf("T1 SELECT command failed: %s", PQerrorMessage(conn));
      PQclear(res);
      exit(1);
    }
    x = atoi(PQgetvalue(res, 0, 0));
    PQclear(res);

    printf("T1:x=%d:x-1=%d\n", x, x-1);
    snprintf(s, NUM_OF_STATEMENT, "SELECT SUM(amount) FROM receipts WHERE batch=%d", x-1);
#ifdef DEBUG
    printf("%s: start\n", s);
#endif
  
    res = PQexec(conn, s);
    if ( PQresultStatus(res) != PGRES_TUPLES_OK ) {
      printf("T1 SELECT SUM command failed: %s", PQerrorMessage(conn));
      PQclear(res);
      res = PQexec(conn, "ROLLBACK");
      if ( PQresultStatus(res) != PGRES_COMMAND_OK ) {
	printf("T1 ROLLBACK failed\n");
      }
      t1_abort_counter[my_thread_id] ++;
      PQclear(res);
      goto retry;
    }
    else {
      y = atoi(PQgetvalue(res, 0, 0));
      PQclear(res);

      printf("T1 pair: %d %d\n", x-1, y);
      snprintf(s, NUM_OF_STATEMENT, "INSERT INTO hoge VALUES (%d, %d)", x-1, y);
      PQexec(conn, s);
      if ( PQresultStatus(res) != PGRES_COMMAND_OK ) {
  	printf("T1:INSERT command failed: %s", PQerrorMessage(conn));
      }
      
      res = PQexec(conn, "COMMIT");
      if ( PQresultStatus(res) != PGRES_COMMAND_OK ) {
	printf("COMMIT of T1 failed: %s", PQerrorMessage(conn));
	PQclear(res);
	printf("T1 ABORTing\n");
	res = PQexec(conn, "ABORT");
	if ( PQresultStatus(res) != PGRES_COMMAND_OK ) {
	  printf("T1 ABORT failed\n");
	}
	t1_abort_counter[my_thread_id] ++;
	printf("T1 ABORTed\n");
	PQclear(res);
	goto retry;
      }
      else {
	PQclear(res);
	gettimeofday(&end_tv, NULL);
	t1_commit_time[my_thread_id] += (1000000 * (end_tv.tv_sec - start_tv.tv_sec ) + (end_tv.tv_usec - start_tv.tv_usec ));
	t1_commit_counter[my_thread_id] ++;
#ifdef DEBUG
	printf("T1_COMMIT_COUNTER:%d MEAN T1_COMMIT_TIME:%d(us)\n\n", t1_commit_counter, t1_commit_time/t1_commit_counter);
#endif
      }
    }
  } // while end
  
  PQfinish(conn);

  pthread_exit(NULL);
}
