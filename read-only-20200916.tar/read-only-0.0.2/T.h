/*
 * Copyright (c) 2018-2018 Takeshi Mishima
 */

/* void *T1(void *); */
/* void *T2(void *); */
/* void *T3(void *); */

pthread_mutex_t mutex_lock;
pthread_cond_t mutex_cond;
int counter = 0;
