/*
 * Copyright (c) 2020-2020 
 */

#include "T1.h"

int
main(int argc, char **argv) {
  int i;
  pthread_t *tids;
  double log(), drand48(), atof();
  int sum_t1_commit_time, sum_t1_abort_time, sum_t1_commit_counter, sum_t1_abort_counter;
  int sum_t1_update_abort_counter, sum_t1_select_abort_counter, sum_t1_prepare_abort_counter, sum_t1_commit_abort_counter;
  
  sum_t1_commit_time = sum_t1_abort_time = sum_t1_commit_counter = sum_t1_abort_counter = 0;
  sum_t1_update_abort_counter = sum_t1_select_abort_counter = sum_t1_prepare_abort_counter = sum_t1_commit_abort_counter = 0;
  
  if (argc != 5 ){
    printf("./T1 arrival_rate num_of_transaction num_of_users seed\n");
    exit(1);
  }

  arrival_rate = atof(argv[1]);
  num_of_transaction = atoi(argv[2]);
  num_of_users = atoi(argv[3]);
  srand48(atoi(argv[4]));
  
  tids = (pthread_t *)malloc(num_of_users * sizeof(pthread_t));

  t1_commit_time = (int *)malloc(num_of_users * sizeof(int));
  t1_abort_time = (int *)malloc(num_of_users * sizeof(int));
  t1_commit_counter = (int *)malloc(num_of_users * sizeof(int));
  t1_abort_counter = (int *)malloc(num_of_users * sizeof(int));

  t1_update_abort_counter = (int *)malloc(num_of_users * sizeof(int));
  t1_select_abort_counter = (int *)malloc(num_of_users * sizeof(int));
  t1_prepare_abort_counter = (int *)malloc(num_of_users * sizeof(int));
  t1_commit_abort_counter = (int *)malloc(num_of_users * sizeof(int));
  
  thread_id = 0;
  thread_id_mutex = (pthread_mutex_t *)malloc(sizeof(pthread_mutex_t));
  pthread_mutex_init(thread_id_mutex, NULL);
  
  for ( i = 0; i < num_of_users; i ++ )
    pthread_create(&tids[i], NULL, T1, NULL );

  for ( i = 0; i < num_of_users; i++ )
    pthread_join(tids[i], NULL);

  for ( i = 0; i < num_of_users; i ++ ) {
    sum_t1_commit_time += t1_commit_time[i];
    sum_t1_abort_time += t1_abort_time[i];
    sum_t1_commit_counter += t1_commit_counter[i];
    sum_t1_abort_counter += t1_abort_counter[i];
    sum_t1_update_abort_counter += t1_update_abort_counter[i];
    sum_t1_select_abort_counter += t1_select_abort_counter[i];
    sum_t1_prepare_abort_counter += t1_prepare_abort_counter[i];
    sum_t1_commit_abort_counter += t1_commit_abort_counter[i];
  }    
    
  printf("T1_throuput: %f [tps]\n", 1000000 * (double)num_of_users * (double)num_of_transaction / (double)sum_t1_commit_time);
  printf("T1_commit_time: %f [us]\n", (double)sum_t1_commit_time/(double)sum_t1_commit_counter);
  if ( sum_t1_abort_counter != 0 )
    printf("T1_abort_time: %f [us]\n", (double)sum_t1_abort_time/(double)sum_t1_abort_counter);
  else
    printf("T1_abort_time: N/A [us]\n");
 printf("T1_commit_counter: %d \n", sum_t1_commit_counter);
  printf("T1_abort_counter: %d \n", sum_t1_abort_counter);

  printf("T1_update_abort_counter: %d \n", sum_t1_update_abort_counter);
  printf("T1_select_abort_counter: %d \n", sum_t1_select_abort_counter);
  printf("T1_prepare_abort_counter: %d \n", sum_t1_prepare_abort_counter);
  printf("T1_commit_abort_counter: %d \n", sum_t1_commit_abort_counter);
  
  
  return 0;
}

void *
T1(void *arg)
{
  const char *conninfo;
  PGconn *conn;
  PGresult *res;
  int i, x, my_thread_id;
  struct timeval tv, start_tv, end_tv;
  char s[NUM_OF_STATEMENT] = {'\0'};

  pthread_mutex_lock(thread_id_mutex);
  my_thread_id =  thread_id ++;
  pthread_mutex_unlock(thread_id_mutex);
  
  //  conninfo = "hostaddr=192.168.100.107 dbname=tpcw user=pgsql password=iseebipai";
  conninfo = "hostaddr=172.31.53.8 port=3333 dbname=testdb user=ubuntu";
    //  conninfo = "dbname=testdb user=test password=abc";
  //select count(*) from receipts  
  conn = PQconnectdb(conninfo);

  if ( PQstatus(conn) != CONNECTION_OK )
    printf("Connection tpcw to database failed: %s", PQerrorMessage(conn));

  for ( i = 0; i < num_of_transaction; i++) {
    gettimeofday(&start_tv, NULL);
  retry:
    tv.tv_sec = 0;
    tv.tv_usec = (long) 1000000 * (x = -1 * log(drand48()) / arrival_rate);
    select(0, NULL, NULL, NULL, &tv);
  
    res = PQexec(conn, "/* OLTP */ BEGIN");
#ifdef DEBUG
    printf("T1:BEGIN\n");
#endif
    if ( PQresultStatus(res) != PGRES_COMMAND_OK ) {
      printf("BEGIN command failed: %s", PQerrorMessage(conn));
      PQclear(res);
      exit(1);
    }
    PQclear(res);

    res = PQexec(conn, "SELECT COUNT(*) FROM doctors WHERE on-call=1");
#ifdef DEBUG
    printf("T1: SELECT COUNT(*)\n");
#endif
    if ( PQresultStatus(res) != PGRES_TUPLES_OK ) {
      printf("T1: SELECT command failed: %s", PQerrorMessage(conn));
      t1_abort_counter[my_thread_id] ++;
      PQclear(res);
      exit(1);
    }
    x = atoi(PQgetvalue(res, 0, 0));
    PQclear(res);
    
    if ( x >= 2) {
      res = PQexec(conn, "UPDATE doctors SET on-call=0 WHRERE name=111");
      if ( PQresultStatus(res) != PGRES_COMMAND_OK ) {
	printf("T1:UPDATE command failed: %s", PQerrorMessage(conn));
	t1_update_abort_counter[my_thread_id] ++;
	res = PQexec(conn, "ROLLBACK");
	if ( PQresultStatus(res) != PGRES_COMMAND_OK ) {
	  printf("T1 UPDATE ROLLBACK failed\n");
	}
	goto retry;
      }
      PQclear(res);
    
#ifdef DEBUG
      printf("T1:PREPARE TRANSACTION 'T1-0'\n");
#endif
      res = PQexec(conn, "PREPARE TRANSACTION 'T1-0'");
      if ( PQresultStatus(res) != PGRES_COMMAND_OK ) {
	printf("PREPARE of T1 failed: %s", PQerrorMessage(conn));
	t1_prepare_abort_counter[my_thread_id] ++;
	PQclear(res);
	goto retry;
      }
      PQclear(res);

      snprintf(s, NUM_OF_STATEMENT, "COMMIT PREPARED 'T1-0'");
      res = PQexec(conn, "COMMIT PREPARED 'T1-0'");
#ifdef DEBUG
      printf("T1:COMMIT PREPARED 'T1-0'\n");
#endif
      if ( PQresultStatus(res) != PGRES_COMMAND_OK ) {
	printf("COMMIT of T1 failed: %s", PQerrorMessage(conn));
	printf("T1 ABORTing\n");
	res = PQexec(conn, "ABORT");
	if ( PQresultStatus(res) != PGRES_COMMAND_OK ) {
	  printf("T1 ABORT failed\n");
	}
	printf("T1 ABORTed\n");
	t1_commit_abort_counter[my_thread_id] ++;
	goto retry;
      }
      PQclear(res);
    } else {
      res = PQexec(conn, "COMMIT");
      PQclear(res);
    }
    gettimeofday(&end_tv, NULL);
    t1_commit_time[my_thread_id] += (1000000 * (end_tv.tv_sec - start_tv.tv_sec ) + (end_tv.tv_usec - start_tv.tv_usec ));
    t1_commit_counter[my_thread_id] ++;

  } // while end
  PQfinish(conn);

  pthread_exit(NULL);
}
