/*
 * Copyright (c) 2020-2020 
 */

#include <stdio.h>
#include <stdlib.h>
#include <libpq-fe.h>
#include <pthread.h>
#include <unistd.h>
#include <stdbool.h>
#include <math.h>
#include <sys/time.h>

#define NUM_OF_STATEMENT 256

void *T2(void *);

double mean_sleep_time;
double arrival_rate;
int num_of_transaction;
int num_of_users;

int *t2_commit_time, *t2_abort_time;
int *t2_commit_counter, *t2_abort_counter;
int *t2_update_abort_counter, *t2_select_abort_counter, *t2_prepare_abort_counter, *t2_commit_abort_counter;
int thread_id;
pthread_mutex_t *thread_id_mutex;

