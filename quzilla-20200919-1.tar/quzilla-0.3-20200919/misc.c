#include "misc.h"

void *
Malloc(size_t size)
{
  void *p;

  if ( (p = malloc(size)) == NULL)
	{
	  perror("malloc");
	  printf("malloc error1\n");
	  exit(EXIT_FAILURE);
	}

  return p;
}

char *
SkipSpace(char *p)
{
  while (*p == ' ')
		p++;
  return p;
}

void
StrAppend(char *dest, char *src)
{
  int cur;
  cur = strlen(dest);
  snprintf(dest + cur, strlen(src) + 1, "%s", src);
  return;
}



void
StrAppendForInt(char *dest, int src)
{
  int cur;
  cur = strlen(dest);
  snprintf(dest + cur, 1 + 1, "%d", src);
  return;
}

int
CountCharLen(char *p)
{
  int len;
  
  for (len = 0; *p != ' ' && *p != '\0'; p++)
	len ++;
  
  return len;
}

int
PopFirstStr(Command *com, char *first)
{
  char *p;
	int len;

	p = com->statement + com->cur;

	/* skip space before the first word */
	for ( ; *p == ' '; p++)
		com->cur++;
	
	/* count up the length of the first word */
  for (len = 0; *p !=' ' && *p != '\0'; p++)
		len++;

  strncpy(first, com->statement + com->cur, len);
	com->cur += len;

	/* skip space after the first word */
	for ( ; *p == ' '; p++)
		com->cur++;
	
  return len;
}

char *
GetSecond(char *statement)
{
	char *p;
	int head = 0;
	int tail;

	p = statement;
	
	/* skip the first character */
	for( ; p[head] != ' '; head++);

	/* skip spaces */
	for( ; p[head] == ' '; head++);

	/* skip the second character */
	for(tail = head; p[tail] != ' '; tail++);

	/* cut the third character */
	p[tail] = '\0';

	return &p[head];

}

void
GetRestCom(Command *com)
{
	char *p;

	for (p = com->statement + com->cur; *p != ' ' && *p != '\0'; p++)
		com->cur++;

	for ( ; *p == ' '; p++)
		com->cur++;
	return;
}

/* GetValue() function tries to find the "key" word.
	 If found, it returns the "value" corresponding to the "key" word.
 */

char *
GetValue(char *statement, char *key)
{
	char *p;
	int head = 0;

	p = statement;
	

	while ( 1 ) {
		/* skip spaces */
		for( ; p[head] == ' '; head++);
		
		if ( strcmp(statement, key) == 0 ) {/* the key word is found */
			return statement;
		}
		else { /* this word is not the key */
			/* skip the word */
			for( ; p[head] != ' '; head++);
		}
	}


	/* not reached */
}

char *
GetFirst(char * statement)
{
	char *p;
	char *first;
	int head = 0;
	int size;

	int tail;

	p = statement;
	size = sizeof(statement);
	first = (char *)Malloc(size);

	/* skip first spaces */
	for( ; p[head] == ' '; head++);
	
	memcpy(first, &p[head], size - head);

	/* skip the first character */
	for( ; p[head] != ' '; head++);

	/* skip spaces */
	for( ; p[head] == ' '; head++);

	/* skip the second character */
	for(tail = head; p[tail] != ' '; tail++);

	/* cut the third character */
	p[tail] = '\0';

	return &p[head];

	
}

int
CountStrLen(char *str)
{
  int len;
  for ( len = 0 ; *str != '\0'; str++) {
    len++;
  }
  return len;
}
