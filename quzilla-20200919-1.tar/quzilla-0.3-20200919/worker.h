/*
 * copyright (c) 2020 
 */

#include <netinet/in.h> /* sockaddr_in */
#include <netdb.h>

/* prototypes */
void *worker(void *);
Task *GetMytaskFromWaitQueue(int);
void PutMyTaskToRunQueue(Task *);
void RecvAndParseQuery(Task *);
void RecvAndParseQuery2(Task *);
int ParseQuery(Task *, int *, int, int *);
void ParseQuery2(Task *, char, int *, int);
void DestroyTask(Task *);
void DisconnExecution(Task *);
void ResetTask(Task *);
void FinishConnection(Task *);
void ExecuteSET(Task *);
void SaveStartupPacket(Task *);
void CopyInitPacket(Task *);
void ExecuteWriteQueryForOLTP(Task *);
void ExecuteSET(Task *);
void ExecuteOLTP_FOR_IDLE(Task *);
void ExecuteOLTP_FOR_SNAPSHOT_CREATED(Task *);
void ExecuteReadSyncForOLTP(Task *);
void ExecutePrepareAndCommitSyncForOLTP(Task *);
void ExecuteSelect1Sync(Task *);
void LeaderFollowerExecution(Task *);
void SendPrepareToOLTPLeader(Task *);
void SendCommitAsync(Task *);
void ExecuteOLAP_FOR_IDLE(Task *);
void ExecuteOLAP_FOR_SNAPSHOT_CREATED(Task *);
void ExecuteCommitSyncForOLAP(Task *);
void ExecuteReadSyncForOLAP(Task *);
void ExecutePrepareSyncForOLTP(Task *);
void ExecuteCommitSyncForOLTP(Task *);
int CheckOLAPDangerousStructure(Task *);
int CheckOLTPDangerousStructure(Task *);
int CheckOLAPCommitDangerousStructure(Task *);
extern void Send(int, void *, int);
extern void Recv(int, void *, int *);
extern void SendAll(Task *);
extern void RecvAll(Task *);
extern void RecvDataFromOne(Task *, int );
extern void SendOthers(Task *);
extern void RecvOthers(Task *);
extern ssize_t Recv2(int, void *, int);
extern void GetChar(char *, char *, int);
extern void GetInt(int *, char *, int);
extern char * GetSecond(char *);
extern void SendOLAPnodes(Task *);
extern void RecvOLAPnodes(Task *);
extern void SendToOLTPandOLAPnode(Task *);
extern void RecvFromOLTPandOLAPnode(Task *);
extern void OLTPSendSet(Task *);
extern void OLTPRecvSet(Task *);
extern void SendAbort(Task *);
extern void SendClient(Task *, int );
extern void SendAllStartupPacket(Task *);
extern void SendOLAPStartupPacket(Task *);
extern void CreateAllBackendConnection(Task *);
extern void CreateOLAPBackendConnection(Task *);
extern void RecvOneServer(Task *, int );
extern void SendOneServer(Task *, int );
extern void SendSelect1(Task *, int);
extern void SendOneServer(Task *, int );
extern void RecvOneServer(Task *, int );
extern void SendPrepareToOthers(Task *);
extern void SendCommitAsync(Task *);
extern void SendRollbackPrepared(Task *, ERR *);
extern void RecvRollbackPrepared(Task *, ERR *);
extern void SendRollbackToFollowers(Task *);
extern void RecvRollbackFromFollowers(Task *);
extern void SendS_5ToFollowers(Task *);
extern void RecvS_5FromFollowers(Task *);

extern System *sys;
extern DATABASE *database;

