/*
 * copyright (c) 2020 Takeshi Mishima
 */

/*            List of relations
 Schema |     Name      | number  |
--------+---------------+-------+---------
 public | customer      | 1 |
 public | district      | 2 |
 public | history       | 3 |
 public | item          | 4 |
 public | new_order     | 5 |
 public | oorder        | 6 |
 public | order_line    | 7 |
 public | stock         | 8 |
 public | warehouse     | 9 |

*/
