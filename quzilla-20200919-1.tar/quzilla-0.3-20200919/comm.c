/*
 * copyright (c) 2020 
 */

#include "comm.h"

void
Disconnect(int fd) {
  close(fd);
  return;
}

int
Listen(const char *service) {
  int sockfd;
  int status;
  const int one = 1;
  struct addrinfo hints;
  struct addrinfo *res, *resptr;

  memset(&hints, 0, sizeof(hints));
  hints.ai_flags = AI_PASSIVE;
  hints.ai_family = AF_INET;
  hints.ai_socktype = SOCK_STREAM;
  
  status = getaddrinfo(NULL, service, &hints, &res);
  if (status != 0) {
    printf("getaddrinfo error in Listen: %d: %s\n", status, gai_strerror(status));
    exit(EXIT_FAILURE);
  }
  for(resptr = res; resptr; resptr = resptr->ai_next){
    sockfd = socket(resptr->ai_family, resptr->ai_socktype, resptr->ai_protocol);
    if ( sockfd > 1000 || sockfd < 0 )
      printf("sockfd=%d\n", sockfd);
    if (sockfd < 0)
      continue;
    if ( (setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one))) < 0){
      printf("setsockopt");
      continue;
    }
    if( bind(sockfd, resptr->ai_addr, resptr->ai_addrlen) == 0)
      break;     /* socket() and bind() are completed successfully and resptr is not NULL \
				  */
    close(sockfd);
  }
  if (resptr == NULL)
    printf("socket or bind");
  
  if (listen(sockfd, MAXLISTENLENGTH) < 0)
    printf("listen");

  freeaddrinfo(res);

  return sockfd;
}

int Accept(int lsnfd) {
  int acfd;
  if ( (acfd = accept(lsnfd, NULL, NULL)) < 0){
    exit(EXIT_FAILURE);
  }
  return acfd;
}

void
Send(int fd, void *buf, int len) {
  int sentlen;

  sentlen = send(fd, buf, len, 0);
  if (sentlen != len)
    printf("Send error\n");

  return;
}

void
Recv(int fd, void *buf, int *len) {
  *len = recv(fd, buf, ANSBUFSZ, 0);
  if (*len < 0)
      return;
  return;
}

void
SendAll(Task *task) {
  int sentlen;
  int i;
  Node *client;

  client = task->client;
  for (i = 0; i < sys->NumOLTPNode + sys->NumOLAPNode; i++) {
    sentlen = send(task->server[i]->fd, client->packet, client->packetlen, 0);
    if (sentlen != client->packetlen) {
      printf("SendSome() error\n");
      exit(EXIT_FAILURE);
    }
  }
  return;
}

void
//RecvDataFromOne(Task *task, int fd, void *packet, int *packetlen) {
RecvDataFromOne(Task *task, int i) {
  int bufhead = 0;
  int bufcur = 0;
  int bufsize = ANSBUFSZ;
  int haverecvd;
  int remained = 0;
  int fd;
  void *packet;
  int *packetlen;

  fd = task->server[i]->fd;
  packet = (void *)task->server[i]->packet;
  packetlen = &task->server[i]->packetlen;
  *packetlen = 0;

#ifdef RECV_DEBUG
  printf("--- receive start %p ---\n", task);
#endif
  
  while (1) {
    /*
     * We try to receive some data from the socket.
     * Note that we may not receive all data.
     */
    haverecvd = Recv2(fd, packet + bufhead, bufsize - bufhead);
    //		printf("I have received %d byte\n", haverecvd);
    //    if ( haverecvd == 0 )
    //      sleep(10000);
    *packetlen += haverecvd;
    bufhead += haverecvd;
    bufsize -= haverecvd;
    
    /* We check whether we have received all data or not */
    if ( CheckDataShortage(task, packet, &bufcur, haverecvd + remained, &remained) == 0)
      /* We have received all data successfully */
      break;

  } /* while end */
  
#ifdef RECV_DEBUG
  printf("--- receive end %p --- \n\n", task);
#endif

  if ( strncmp(packet + 20, "SERROR", 6) == 0 || strncmp(packet + 5, "SERROR", 6) == 0 ) {
    task->server[i]->error = SERROR;
  }
  if ( strncmp( task->server[i]->packet + 20, "ROLLBACK", 8) == 0 || strncmp(packet + 20, "ROLLBACK", 8) == 0 )
    task->server[i]->error = ROLLBACK_ERROR;
  return;
}

int
CheckDataShortage(Task *task, void *p, int *cur, int datalen, int *remained) {
  char command;
  int strlen;

  while(datalen > 0){
    if (datalen <= 5) {
      *remained = datalen;
      return 1;
    }
    
    GetChar(&command, p + *cur, 1);
    GetInt(&strlen, p + *cur + 1, 4);
#ifdef RECV_DEBUG
    if ( task->ttype != OLAP )
      printf("%p: [%c] [%d] [%s] : [%d]\n", task, command, strlen, (char *)(p + *cur + 5), datalen - strlen - 1);
#endif
    if (datalen >= strlen + 1) {
      datalen -= strlen + 1;
      *cur += strlen + 1;
    }
    else {
      /* return to re-receive data length */
      *remained = datalen;
      return 1;
    }
  }
  
  if (command == 'Z' && datalen == 0){
    /* we have received all data successfully */
    return 0;
  }
  else if (datalen == 0) {
    /* Eventually datalen equals 0 but we have not received all data yet */
    *remained = 0;
    return 1;
  }
  else {
    /* not reached */
    printf("[FATAL] CheckDataShortage() Error\n");
    exit(EXIT_FAILURE);
  }
}

ssize_t
Recv2(int fd, void *buf, int len) {/* this function must not be removed */
  int datalen;
  //  datalen = recv(fd, buf, len, 0);
  datalen = read(fd, buf, len);

  //  printf("I have received %d bytes.\n", datalen);

  if (datalen < 0) {
	  printf("Recv2 data shortage error\n");
	  return -1;
	}
  return datalen;
}

void
GetChar(char *result, char *data, int len) {
  memcpy(result, data, len);
}

void
GetInt(int *result, char *data, int len) {
  int raw;

  memcpy(&raw, data, len);
  *result = ntohl(raw);
}

unsigned long Checksum(unsigned short *data, int length) {
  unsigned long sum = 0;

  while (length > 1) {
    sum += *(data++);
    length -= 2;
  }
  
  if (length > 0)
    sum += (*data) & 0x00ff;

  return sum;
}

void
RecvAll(Task *task) {
  int i;
    
  for (i = 0; i < sys->NumOLTPNode + sys->NumOLAPNode; i++) {
    RecvDataFromOne(task, i);
  }
    
  return;
}

void
RecvOneServer(Task *task, int nodenum) {
  RecvDataFromOne(task, nodenum);
  return;
}


int
CheckDataShortage2(void *p, int *cur, int datalen, int *remained) {
  char command;
  int strlen;

  while(datalen > 0){
    if (datalen <= 5) {
      *remained = datalen;
      return 1;
    }
    
    GetChar(&command, p + *cur, 1);
    GetInt(&strlen, p + *cur + 1, 4);
#ifdef RECV_DEBUG
    printf(": [%c] [%d] [%s] : [%d]\n", command, strlen, (char *)(p + *cur + 5), datalen - strlen - 1);
#endif
    if (datalen >= strlen + 1) {
      datalen -= strlen + 1;
      *cur += strlen + 1;
    }
    else {
      /* return to re-receive data length */
      *remained = datalen;
      return 1;
    }
  }
  
  if (command == 'Z' && datalen == 0){
    /* we have received all data successfully */
    return 0;
  }
  else if (datalen == 0) {
    /* Eventually datalen equals 0 but we have not received all data yet */
    *remained = 0;
    return 1;
  }
  else {
    /* not reached */
    printf("[FATAL] CheckDataShortage() Error\n");
    exit(EXIT_FAILURE);
  }
}

void
SendClient(Task *task, int nodenum) {
  Send(task->client->fd, task->server[nodenum]->packet, task->server[nodenum]->packetlen);
  return;
}

void
SendOneServer(Task *task, int nodenum) {
  char *packet;
  int sentlen, packetlen;

  packet = task->client->packet;
  packetlen = task->client->packetlen;
  sentlen = send(task->server[nodenum]->fd, packet, packetlen, 0);
  if (sentlen != packetlen) {
    printf("SendOne\n");
    exit(EXIT_FAILURE);
  }
    
  return;
}

void
SendAllStartupPacket(Task *task) {
  int sentlen;
  int i;
  Node **server;

  server = task->server;

  for (i = 0; i <  sys->NumOLTPNode + sys->NumOLAPNode; i++) {
    sentlen = send(server[i]->fd, task->InitPacket.startup_packet, task->InitPacket.startup_packetlen, 0);
    if (sentlen != task->InitPacket.startup_packetlen) {
      printf("send() in SendAllStartupPacket\n");
      exit(EXIT_FAILURE);
    }
  }  // for end
  return;
}

void
SendOLAPStartupPacket(Task *task) {
  Node **server;
  int sentlen;
  
  server = task->server;

  sentlen = send(server[task->mynode]->fd, task->InitPacket.startup_packet, task->InitPacket.startup_packetlen, 0);
  if (sentlen != task->InitPacket.startup_packetlen) {
    printf("send() in SendOLAPStartupPacket\n");
    exit(EXIT_FAILURE);
  }
  
  return;
}

void
CreateAllBackendConnection(Task *task) {
  int status;
  int i;
  struct addrinfo hints;
  struct addrinfo *res;
	
  for (i = 0; i < sys->NumOLTPNode + sys->NumOLAPNode; i++) {
    memset(&hints, 0, sizeof(hints));
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_STREAM;
		
    status = getaddrinfo(database[task->database_id].server.server_name[i],
			 database[task->database_id].server.server_port, &hints, &res);

    if (status != 0) {
      printf("getaddrinfo()\n");
      exit(EXIT_FAILURE);
    }
		
    if ( (task->server[i]->fd = socket(res->ai_family, res->ai_socktype, res->ai_protocol) ) < 0 ) {
      printf("socket()\n");
      exit(EXIT_FAILURE);
    }
		
    if (connect(task->server[i]->fd, res->ai_addr, res->ai_addrlen) < 0){
      printf("connect()\n");
      close(task->server[i]->fd);
      exit(EXIT_FAILURE);
    }
    
    freeaddrinfo(res);
  } /* for loop end */
  return;
}

void
CreateOLAPBackendConnection(Task *task) {
  int status;
  struct addrinfo hints;
  struct addrinfo *res;
	
  memset(&hints, 0, sizeof(hints));
  hints.ai_family = AF_UNSPEC;
  hints.ai_socktype = SOCK_STREAM;
		
  status = getaddrinfo(database[task->database_id].server.server_name[task->mynode],
		       database[task->database_id].server.server_port, &hints, &res);
  if (status != 0) {
    printf("getaddrinfo()\n");
    exit(EXIT_FAILURE);
  }
		
  if ( (task->server[task->mynode]->fd = socket(res->ai_family, res->ai_socktype, res->ai_protocol) ) < 0 ) {
    printf("socket()\n");
    exit(EXIT_FAILURE);
  }
		
  if (connect(task->server[task->mynode]->fd, res->ai_addr, res->ai_addrlen) < 0){
    printf("connect()\n");
    close(task->server[task->mynode]->fd);
    exit(EXIT_FAILURE);
  }

  freeaddrinfo(res);

  return;
}

void
SendSelect1(Task *task, int nodenum) {
  int sentlen;

  sentlen = send(task->server[nodenum]->fd, task->select1_packet, task->select1_packetlen, 0);
  if (sentlen != task->select1_packetlen) {
    printf("SendSelect1 error\n");
    exit(EXIT_FAILURE);
  }

  return;
}

void
SendOthers(Task *task) {
  int sentlen;
  int i;

  for (i = sys->NumOLTPNode; i < sys->NumOLTPNode + sys->NumOLAPNode; i++) {
    sentlen = send(task->server[i]->fd, task->client->packet, task->client->packetlen, 0);
    if (sentlen != task->client->packetlen ) {
      printf("SendOthers error\n");
      exit(EXIT_FAILURE);
    }
  }
  return;
}

void
RecvOthers(Task *task) {
  int i;
    
  for (i = sys->NumOLTPNode; i < sys->NumOLTPNode + sys->NumOLAPNode; i++) {
    RecvDataFromOne(task, i);
  }
  return;
}

void
SendPrepareToOLTPLeader(Task *task) {
  int sentlen;
  
  sentlen = send(task->server[0]->fd, task->prepare_packet, task->prepare_packetlen, 0);
  if (sentlen != task->prepare_packetlen) {
    printf("prepare error\n");
    exit(EXIT_FAILURE);
  }

  return;
}

void
SendPrepareToOthers(Task *task) {
  int sentlen, i;

  for (i = sys->NumOLTPNode; i < sys->NumOLTPNode + sys->NumOLAPNode; i++) {
    sentlen = send(task->server[i]->fd, task->prepare_packet, task->prepare_packetlen, 0);
    if (sentlen != task->prepare_packetlen) {
      printf("prepare error\n");
      exit(EXIT_FAILURE);
    }
  }
  return;
}

void
SendCommitAsync(Task *task) {
  int i, sentlen;

  for (i = 0; i < sys->NumOLTPNode + sys->NumOLAPNode; i++) {
    sentlen = send(task->server[i]->fd, task->commit_prepared_packet, task->commit_prepared_packetlen, 0);
    if (sentlen != task->commit_prepared_packetlen) {
      printf("commit error\n");
      exit(EXIT_FAILURE);
    }
  }
  return;
}

void
SendRollbackPrepared(Task *task, ERR *error_server) {
  int sentlen, i;

  for (i = 0; i < sys->NumOLTPNode + sys->NumOLAPNode; i++) {
    if ( error_server[i] == NOERROR ) {
      sentlen = send(task->server[i]->fd, task->rollback_prepared_packet, task->rollback_prepared_packetlen, 0);
      if (sentlen != task->rollback_prepared_packetlen) {
	printf("prepare error\n");
	exit(EXIT_FAILURE);
      }
    } else ;   // error server rollbacks automatically
  }
  return;
}


void
RecvRollbackPrepared(Task *task, ERR *error_server) {
  int i;
  for (i = 0; i < sys->NumOLTPNode + sys->NumOLAPNode; i++) {
    if ( error_server[i] == NOERROR ) {
      RecvOneServer(task, i);
    }
  }
  return;
}

void
SendRollbackToFollowers(Task *task) {
  int sentlen, i; 

  for (i = 1; i < sys->NumOLTPNode + sys->NumOLAPNode; i++) {
    sentlen = send(task->server[i]->fd, task->rollback_packet, task->rollback_packetlen, 0);
    if (sentlen != task->rollback_packetlen) {
      printf("rollback error\n");
      exit(EXIT_FAILURE);
    }
  }
  return;
}
  
void
RecvRollbackFromFollowers(Task *task) {
  int i;
  for (i = 1; i < sys->NumOLTPNode + sys->NumOLAPNode; i++)
    RecvOneServer(task, i);
  return;
}

void
SendS_5ToFollowers(Task *task) {
  int sentlen, i; 
  for (i = 1; i < sys->NumOLTPNode + sys->NumOLAPNode; i++) {
    if ( task->S_5_counter[i]++ == 0 ) {
      sentlen = send(task->server[i]->fd, task->S_5_P_packet, task->S_5_P_packetlen, 0);
      if (sentlen != task->S_5_P_packetlen) {
	printf("rollback P error\n");
	exit(EXIT_FAILURE);
      }
    } else {
      sentlen = send(task->server[i]->fd, task->S_5_B_packet, task->S_5_B_packetlen, 0);      
      if (sentlen != task->S_5_B_packetlen) {
	printf("rollback B error\n");
	exit(EXIT_FAILURE);
      }
    }
  } // for end
  return;
}
  
void
RecvS_5FromFollowers(Task *task) {
  int i;
  for (i = 1; i < sys->NumOLTPNode + sys->NumOLAPNode; i++)
    RecvOneServer(task, i);
  return;
}
