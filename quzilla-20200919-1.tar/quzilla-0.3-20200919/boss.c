/*
 * copyright (c) 2020 
 */

#include <sys/socket.h>
#include "quzilla.h"
#include "boss.h"
#include "c.h"

void *
Boss(void *arg)
{
  int lsnfd, acfd;
  Task *task;
  int thread_counter = 1001;
  
  lsnfd = Listen(sys->clientport);
	
  while ( 1 ) {
    acfd = Accept(lsnfd);
    task = CreateTask(acfd, &thread_counter);
    SelectMyNode(task);
    Recv(task->client->fd, task->InitPacket.startup_packet, &task->InitPacket.startup_packetlen);
    CheckUser(task);
    PutTaskToWaitQueue(task);
  } /* while loop end */
}

Task *
CreateTask(int acfd, int *thread_counter) {
  Task *task;
  int i;
	
  task = (Task *)Malloc(sizeof(Task));
  task->status = OLTP_IDLE;
  task->thread_id = (*thread_counter) ++;
  task->database_id = 0;
  task->mynode = -1;
  task->commit_counter = 0;
  task->this_commit_query_type = 0;
  task->commit_query_type[1] = ROLLBACK_QUERY;
  task->commit_query_type[2] = ROLLBACK_QUERY;
  task->commit_query_type[3] = ROLLBACK_QUERY;
  /* for a new TCP connection */
  task->InitPacket.startup_packet = (char *)Malloc(QUERYBUFSZ);
  task->InitPacket.startup_packetlen = 0;
  task->InitPacket.setup1_packet = (char *)Malloc(QUERYBUFSZ);
  task->InitPacket.setup1_packetlen = 0;
  task->InitPacket.setup2_packet = (char *)Malloc(QUERYBUFSZ);
  task->InitPacket.setup2_packetlen = 0;
  task->InitPacket.executed = false;
  /* for transaction */
  task->ttype = NOTRAN;
  /* for client */
  task->client = (Node *)Malloc(sizeof(Node));
  task->client->fd = acfd;
  task->client->packet = (char *)Malloc(QUERYBUFSZ);
  task->tmp_packet = (char *)Malloc(QUERYBUFSZ);
  task->rollback_packet = (char *)Malloc(QUERYBUFSZ);
  task->qtype = NOQUERY;
  /* for servers */
  task->server = (Node **)Malloc((sys->NumOLTPNode + sys->NumOLAPNode) * sizeof(Node *));
  task->S_5_counter = (int *)Malloc((sys->NumOLTPNode + sys->NumOLAPNode) * sizeof(int));
  for (i = 0; i < (sys->NumOLTPNode + sys->NumOLAPNode); i++) {
    task->server[i] = (Node *)Malloc(sizeof(Node));
    task->server[i]->fd = -1;
    task->server[i]->packet = (char *)Malloc(ANSBUFSZ);
    task->server[i]->error = NOERROR;
    task->S_5_counter[i] = 0;
  }
  GetSelect1(task);
  GetPrepare(task);
  GetCommitPrepared(task);
  GetCommitSuccess1(task);
  GetCommitSuccess2(task);
  GetCommitError1(task);
  GetCommitError2(task);
  GetRollback1(task);
  GetRollback2(task);
  GetRollbackPrepared(task);
  GetS_5_P(task);
  GetS_5_B(task);
  return task;
}

void
PutTaskToWaitQueue(Task *task)
{
  Queue *wq; /* wait queue */
  Task *head, *tail;
  
  wq = &database[task->database_id].wait_queue;
  pthread_mutex_lock(wq->queue_mutex);

  head = &wq->head;
  tail = head->prev;
  if (wq->len == 0) {
    head->next = head->prev = task;
    task->next = task->prev = head;
  }
  else {
    task->prev = tail;
    tail->next = task;
    head->prev = task;
    task->next = head;
  }
  wq->len ++;
  pthread_cond_signal(wq->queue_cond);

  pthread_mutex_unlock(wq->queue_mutex);

  return;
}

void
CheckUser(Task *task) {
  task->OLTPNode = task->OLAPNode = -1;
  if ( strcmp (task->InitPacket.startup_packet+13, sys->OLTPUser) == 0 ) {
    task->OLTPNode = 0;
    if ( sys->NumOLAPNode == 0 )
      task->OLAPNode = 0;
    else
      task->OLAPNode = lrand48() % sys->NumOLAPNode + 1;
  }
  else if ( strcmp ( task->InitPacket.startup_packet+13, sys->OLAPUser ) == 0 ) {
    if ( sys->NumOLAPNode == 0 ) {
      printf("CheckUser error\n");
      exit(EXIT_FAILURE);
    }
    else
      task->OLAPNode = lrand48() % sys->NumOLAPNode + 1;
  }
  else {
    //    printf("user error\n");
    sleep(100000);
    printf("sorry, shut down\n");
    exit(EXIT_FAILURE);
  }
  return;
}   

void
GetSelect1(Task *task) {
  FILE *fp_packet, *fp_packetlen;
  char fname_packet[] = "select1.bin";
  char fname_packetlen[] = "select1.num";
  char *len;

  len = (char *)malloc(sizeof(char));
  fp_packet = fopen(fname_packet, "r");
  fp_packetlen = fopen(fname_packetlen, "r");
  if(fp_packet == NULL) {
    printf("%s file not open!\n", fname_packet);
    exit(EXIT_FAILURE);
  }
  if(fp_packetlen == NULL) {
    printf("%s file not open!\n", fname_packetlen);
    exit(EXIT_FAILURE);
  }
  fread(len, 4, 1, fp_packetlen);
  task->select1_packet = (char *)Malloc(QUERYBUFSZ);
  fread(task->select1_packet, atoi(len), 1, fp_packet);
  task->select1_packetlen = atoi(len);
  fclose(fp_packet);
  fclose(fp_packetlen);
  return;
}

void
GetPrepare(Task *task) {
  FILE *fp_packet;
  FILE *fp_packetlen;
  char fname_packet[] = "prepare.bin";
  char fname_packetlen[] = "prepare.num";
  char *len;

  len = (char *)malloc(sizeof(char));
  fp_packet = fopen(fname_packet, "r");
  fp_packetlen = fopen(fname_packetlen, "r");
  if(fp_packet == NULL) {
    printf("%s file not open!\n", fname_packet);
    exit(EXIT_FAILURE);
  }
  if(fp_packetlen == NULL) {
    printf("%s file not open!\n", fname_packetlen);
    exit(EXIT_FAILURE);
  }
  task->prepare_packet = (char *)Malloc(QUERYBUFSZ);
  fread(task->prepare_packet, 31, 1, fp_packet);
 snprintf(task->prepare_packet + 31, 5, "%d", task->thread_id);
  fseek(fp_packet, 35, 0);
  fread(task->prepare_packet+35, 39, 1, fp_packet);
  fread(len, 4, 1, fp_packetlen);
  task->prepare_packetlen = atoi(len);
  fclose(fp_packet);
  fclose(fp_packetlen);

  return;
}

void
GetRollbackPrepared(Task *task) {
  FILE *fp_packet;
  FILE *fp_packetlen;
  char fname_packet[] = "rollback-prepared.bin";
  char fname_packetlen[] = "rollback-prepared.num";
  char *len;

  len = (char *)malloc(sizeof(char));
  fp_packet = fopen(fname_packet, "r");
  fp_packetlen = fopen(fname_packetlen, "r");
  if(fp_packet == NULL) {
    printf("%s file not open!\n", fname_packet);
    exit(EXIT_FAILURE);
  }
  if(fp_packetlen == NULL) {
    printf("%s file not open!\n", fname_packetlen);
    exit(EXIT_FAILURE);
  }
  fread(len, 4, 1, fp_packetlen);
  task->rollback_prepared_packetlen = atoi(len);
  task->rollback_prepared_packet = (char *)Malloc(QUERYBUFSZ);
  fread(task->rollback_prepared_packet, 35, 1, fp_packet);
  snprintf(task->rollback_prepared_packet + 29, 5, "%d", task->thread_id);
  fseek(fp_packet, 33, 0);
  fread(task->rollback_prepared_packet+33, task->rollback_prepared_packetlen - 33, 1, fp_packet);
  fclose(fp_packet);
  fclose(fp_packetlen);

  return;
}

void
GetCommitPrepared(Task *task) {
  FILE *fp_packet;
  FILE *fp_packetlen;
  char fname_packet[] = "commit-prepared.bin";
  char fname_packetlen[] = "commit-prepared.num";
  char *len;

  len = (char *)malloc(sizeof(char));
  fp_packet = fopen(fname_packet, "r");
  fp_packetlen = fopen(fname_packetlen, "r");
  if(fp_packet == NULL) {
    printf("%s file not open!\n", fname_packet);
    exit(EXIT_FAILURE);
  }
  if(fp_packetlen == NULL) {
    printf("%s file not open!\n", fname_packetlen);
    exit(EXIT_FAILURE);
  }
  task->commit_prepared_packet = (char *)Malloc(QUERYBUFSZ);
  fread(task->commit_prepared_packet, 27, 1, fp_packet);
  snprintf(task->commit_prepared_packet + 27, 5, "%d", task->thread_id);
  fseek(fp_packet, 31, 0);  
  fread(task->commit_prepared_packet+31, 40, 1, fp_packet);
  fread(len, 4, 1, fp_packetlen);
  task->commit_prepared_packetlen = atoi(len);
  fclose(fp_packet);
  fclose(fp_packetlen);
  return;
}

void
GetCommitSuccess1(Task *task) {
  FILE *fp_packet, *fp_packetlen;
  char fname_packet[] = "commit-success1.bin";
  char fname_packetlen[] = "commit-success1.num";
  char *len;

  len = (char *)malloc(sizeof(char));
  fp_packet = fopen(fname_packet, "r");
  fp_packetlen = fopen(fname_packetlen, "r");
  if(fp_packet == NULL) {
    printf("%s file not open!\n", fname_packet);
    exit(EXIT_FAILURE);
  }
  if(fp_packetlen == NULL) {
    printf("%s file not open!\n", fname_packetlen);
    exit(EXIT_FAILURE);
  }
  fread(len, 4, 1, fp_packetlen);
  task->commit_success1_packet = (char *)Malloc(QUERYBUFSZ);
  fread(task->commit_success1_packet, atoi(len), 1, fp_packet);
  task->commit_success1_packetlen = atoi(len);
  fclose(fp_packet);
  fclose(fp_packetlen);
  return;
}


void
GetCommitSuccess2(Task *task) {
  FILE *fp_packet, *fp_packetlen;
  char fname_packet[] = "commit-success2.bin";
  char fname_packetlen[] = "commit-success2.num";
  char *len;

  len = (char *)malloc(sizeof(char));
  fp_packet = fopen(fname_packet, "r");
  fp_packetlen = fopen(fname_packetlen, "r");
  if(fp_packet == NULL) {
    printf("%s file not open!\n", fname_packet);
    exit(EXIT_FAILURE);
  }
  if(fp_packetlen == NULL) {
    printf("%s file not open!\n", fname_packetlen);
    exit(EXIT_FAILURE);
  }
  fread(len, 4, 1, fp_packetlen);
  task->commit_success2_packet = (char *)Malloc(QUERYBUFSZ);
  fread(task->commit_success2_packet, atoi(len), 1, fp_packet);
  task->commit_success2_packetlen = atoi(len);
  fclose(fp_packet);
  fclose(fp_packetlen);
  return;
}

void
GetCommitError1(Task *task) {
  FILE *fp_packet, *fp_packetlen;
  char fname_packet[] = "commit-error1.bin";
  char fname_packetlen[] = "commit-error1.num";
  char *len;

  len = (char *)malloc(sizeof(char));
  fp_packet = fopen(fname_packet, "r");
  fp_packetlen = fopen(fname_packetlen, "r");
  if(fp_packet == NULL) {
    printf("%s file not open!\n", fname_packet);
    exit(EXIT_FAILURE);
  }
  if(fp_packetlen == NULL) {
    printf("%s file not open!\n", fname_packetlen);
    exit(EXIT_FAILURE);
  }
  fread(len, 4, 1, fp_packetlen);
  task->commit_error1_packet = (char *)Malloc(QUERYBUFSZ);
  fread(task->commit_error1_packet, atoi(len), 1, fp_packet);
  task->commit_error1_packetlen = atoi(len);
  fclose(fp_packet);
  fclose(fp_packetlen);
  return;
}

void
GetCommitError2(Task *task) {
  FILE *fp_packet, *fp_packetlen;
  char fname_packet[] = "commit-error2.bin";
  char fname_packetlen[] = "commit-error2.num";
  char *len;

  len = (char *)malloc(sizeof(char));
  fp_packet = fopen(fname_packet, "r");
  fp_packetlen = fopen(fname_packetlen, "r");
  if(fp_packet == NULL) {
    printf("%s file not open!\n", fname_packet);
    exit(EXIT_FAILURE);
  }
  if(fp_packetlen == NULL) {
    printf("%s file not open!\n", fname_packetlen);
    exit(EXIT_FAILURE);
  }
  fread(len, 4, 1, fp_packetlen);
  task->commit_error2_packet = (char *)Malloc(QUERYBUFSZ);
  fread(task->commit_error2_packet, atoi(len), 1, fp_packet);
  task->commit_error2_packetlen = atoi(len);
  fclose(fp_packet);
  fclose(fp_packetlen);
  return;
}

void
GetRollback1(Task *task) {
  FILE *fp_packet, *fp_packetlen;
  char fname_packet[] = "rollback1.bin";
  char fname_packetlen[] = "rollback1.num";
  char *len;

  len = (char *)malloc(sizeof(char));
  fp_packet = fopen(fname_packet, "r");
  fp_packetlen = fopen(fname_packetlen, "r");
  if(fp_packet == NULL) {
    printf("%s file not open!\n", fname_packet);
    exit(EXIT_FAILURE);
  }
  if(fp_packetlen == NULL) {
    printf("%s file not open!\n", fname_packetlen);
    exit(EXIT_FAILURE);
  }
  fread(len, 4, 1, fp_packetlen);
  task->rollback1_packet = (char *)Malloc(QUERYBUFSZ);
  fread(task->rollback1_packet, atoi(len), 1, fp_packet);
  task->rollback1_packetlen = atoi(len);
  fclose(fp_packet);
  fclose(fp_packetlen);
  return;
}

void
GetRollback2(Task *task) {
  FILE *fp_packet, *fp_packetlen;
  char fname_packet[] = "rollback2.bin";
  char fname_packetlen[] = "rollback2.num";
  char *len;

  len = (char *)malloc(sizeof(char));
  fp_packet = fopen(fname_packet, "r");
  fp_packetlen = fopen(fname_packetlen, "r");
  if(fp_packet == NULL) {
    printf("%s file not open!\n", fname_packet);
    exit(EXIT_FAILURE);
  }
  if(fp_packetlen == NULL) {
    printf("%s file not open!\n", fname_packetlen);
    exit(EXIT_FAILURE);
  }
  fread(len, 4, 1, fp_packetlen);
  task->rollback2_packet = (char *)Malloc(QUERYBUFSZ);
  fread(task->rollback2_packet, atoi(len), 1, fp_packet);
  task->rollback2_packetlen = atoi(len);
  fclose(fp_packet);
  fclose(fp_packetlen);
  return;
}

void
SelectMyNode(Task *task) {
  if ( sys->NumOLAPNode < 1 )
    task->mynode = 0;
  else
    //    do {
      //      task->mynode = lrand48() % sys->NumOLAPNode;
      task->mynode = lrand48() % ( sys->NumOLTPNode + sys->NumOLAPNode );
      //    } while ( task->mynode < 1 );

  return;
}

void
GetS_5_P(Task *task) {
  FILE *fp_packet, *fp_packetlen;
  char fname_packet[] = "S_5_P_ROLLBACK.bin";
  char fname_packetlen[] = "S_5_P_ROLLBACK.num";
  char *len;

  len = (char *)malloc(sizeof(char));
  fp_packet = fopen(fname_packet, "r");
  fp_packetlen = fopen(fname_packetlen, "r");
  if(fp_packet == NULL) {
    printf("%s file not open!\n", fname_packet);
    exit(EXIT_FAILURE);
  }
  if(fp_packetlen == NULL) {
    printf("%s file not open!\n", fname_packetlen);
    exit(EXIT_FAILURE);
  }
  fread(len, 4, 1, fp_packetlen);
  task->S_5_P_packet = (char *)Malloc(QUERYBUFSZ);
  fread(task->S_5_P_packet, atoi(len), 1, fp_packet);
  task->S_5_P_packetlen = atoi(len);
  fclose(fp_packet);
  fclose(fp_packetlen);
  return;
}

void
GetS_5_B(Task *task) {
  FILE *fp_packet, *fp_packetlen;
  char fname_packet[] = "S_5_B_ROLLBACK.bin";
  char fname_packetlen[] = "S_5_B_ROLLBACK.num";
  char *len;

  len = (char *)malloc(sizeof(char));
  fp_packet = fopen(fname_packet, "r");
  fp_packetlen = fopen(fname_packetlen, "r");
  if(fp_packet == NULL) {
    printf("%s file not open!\n", fname_packet);
    exit(EXIT_FAILURE);
  }
  if(fp_packetlen == NULL) {
    printf("%s file not open!\n", fname_packetlen);
    exit(EXIT_FAILURE);
  }
  fread(len, 4, 1, fp_packetlen);
  task->S_5_B_packet = (char *)Malloc(QUERYBUFSZ);
  fread(task->S_5_B_packet, atoi(len), 1, fp_packet);
  task->S_5_B_packetlen = atoi(len);
  fclose(fp_packet);
  fclose(fp_packetlen);
  return;
}
