/*
 * copyright (c) 2020 
 */

#include <stdio.h>
#include <libpq-fe.h>
#include <pthread.h>
#include <unistd.h>
#include <stdbool.h>
#include "c.h"
#include "misc.h"
#include "relation.h"

#undef Max
#define Max(x, y) ((x) > (y) ? (x) : (y))
#undef Min
#define Min(x, y) ((x) < (y) ? (x) : (y))

//#define ANSBUFSZ 262144 /* this must be big enough */
//#define ANSBUFSZ 524288 /* this must be big enough */
#define ANSBUFSZ 200000000 /* this must be big enough */
#define VERSION 0.2

#define COMSZ 128 /* this size must be the same as COMBUFSZ in command.h */
#define NUM_TABLE 16
#define TABLE_NAME_LENGTH 16

typedef struct {
  char *name;
  char *port;
} Host;

typedef enum ERR {
  NOERROR,
  SERROR,
  ROLLBACK_ERROR,
} ERR;

typedef enum SET_STATUS {
  SET_INVALID,
  SET_VALID,
} SET_STATUS;

typedef struct {
  SET_STATUS InitFlag;
  bool executed;
  pthread_mutex_t *InitFlagMutex;
  pthread_cond_t *InitFlagCond;
  char *startup_packet;
  int startup_packetlen;
  char *setup1_packet;
  int setup1_packetlen;
  char *setup2_packet;
  int setup2_packetlen;
} IP;

#define MAX_NUM_NODE 8
#define MAX_NODE_NAME_LENGTH 16
#define MAX_DATABASE 1

typedef enum {
  SERIALIZABLE,
  SNAPSHOT_ISOLATION,
} ISOLATION;  

typedef struct {
  int status;
  char com[COMSZ];
  char *serverport;
  char *clientport;
  char *opsport;
  pthread_t bid;
  Host host[MAX_NUM_NODE];
  IP InitPacket;
  int NumOLTPNode;
  int NumOLTPThread;
  char *OLTPUser;
  int NumOLAPNode;
  int NumOLAPThread;
  char *OLAPUser;
  char *OLAPisolation;
  pthread_mutex_t *OLAP_mutex;
} System;

System *sys;

typedef enum QUERYTYPE {
  SNAPSHOT,
  BEGIN,
  COMMIT,
  PREPARE,
  READ,
  WRITE,
  OTHER,
  ROLLBACK,
  ABORT,
  SET,
  NOQUERY,
  LOCK,
  DISCONN,
} QUERYTYPE;

typedef enum TRANTYPE {
 NOTRAN,
 SETTRAN,
 OLAP,
 OLTP,
} TRANTYPE;

typedef struct {
  int fd;           /* accepted fd */
  char *packet;
  int packetlen;
  ERR error;
} Node;

#define QUERYBUFSZ 2048

#define MAX_NUM_PACKET 64
#define OLTP_NODE 0

typedef enum PACKET_TYPE {
  PACKET_EMPTY,
  PACKET_IGNORE,
  PACKET_BEGIN,
  PACKET_READ,
  PACKET_WRITE,
  PACKET_COMMIT
} PACKET_TYPE;

typedef struct PACKET_SET {
  char *packet;
  int packetlen;
  PACKET_TYPE PacketType;
} PACKET_SET;

#define NUM_OLAP_SERVER 4
#define NUM_BENCH_TABLE 16

typedef enum WORKER_STATUS {
  WORKER_INVALID,     // worker does not execute this transaction yet
  WORKER_EXECUTING,   // worker is executing this transaction
  WORKER_COMMITTED,   // worker has committed this transaction
} WORKER_STATUS;

typedef enum STATUS {
  OLTP_IDLE,
  OLTP_SNAPSHOT_CREATED,
  OLAP_IDLE,
  OLAP_SNAPSHOT_CREATED,
} STATUS;

typedef enum COMMIT_QUERY_TYPE {
  NO_QUERY_TYPE,
  TRY_COMMIT_QUERY,
  COMMIT_QUERY,
  ROLLBACK_QUERY,
  ERROR_QUERY,
} COMMIT_QUERY_TYPE;

typedef struct Task {
  STATUS status;
  int thread_id;
  int database_id;
  int mynode;
  IP InitPacket;
  char *select1_packet;
  int select1_packetlen;
  char *prepare_packet;
  int prepare_packetlen;
  char *tmp_packet;
  int commit_counter;
  int this_commit_query_type;
  COMMIT_QUERY_TYPE commit_query_type[4];   // S_0, S_1, S_?
  char *commit_prepared_packet;
  int commit_prepared_packetlen;
  char *commit_success1_packet;
  int commit_success1_packetlen;
  char *commit_success2_packet;
  int commit_success2_packetlen;
  char *commit_error1_packet;
  int commit_error1_packetlen;
  char *commit_error2_packet;
  int commit_error2_packetlen;
  char *S_5_P_packet;
  int S_5_P_packetlen;
  char *S_5_B_packet;
  int S_5_B_packetlen;
  int *S_5_counter;
  char *rollback_packet;
  int rollback_packetlen;
  char *rollback1_packet;
  int rollback1_packetlen;
  char *rollback2_packet;
  int rollback2_packetlen;
  char *rollback_prepared_packet;
  int rollback_prepared_packetlen;
  /* transaction */
  TRANTYPE ttype;        /* transaction type */
  /* client */
  Node *client;
  QUERYTYPE qtype;        /* query type */
  //  int qtype;        /* query type */
  /* server */
  int OLTPNode;
  int OLAPNode;
  Node **server;
  /* task queue */
  struct Task *prev;
  struct Task *next;
} Task;

typedef struct {
  int len;
  Task head;
  pthread_mutex_t *queue_mutex;
  pthread_cond_t *queue_cond;
} Queue;

typedef struct {
  char **server_name;    /* server name */
  char *server_port;
  int numactsrv;           /* number of active servers */
} Server;

typedef struct DATABASE {
  char *database_name;
  Server server;
  pthread_t *wids;       /* worker ids */
  Queue wait_queue;
  Queue run_queue;
  char *startup_packet;
  int startup_packetlen;
} DATABASE;

#define NAMELENGTH 32
#define MAXNUMCHECKRUNQUEUE 1000

typedef enum TABLE_NUM {
  warehouse = 0x1,
  stock = 0x2,
  item = 0x3,
  orderline = 0x4,
  neworder = 0x5,
  history = 0x6,
  district = 0x7,
  customer = 0x8,
  order = 0x9,
  region = 0xa,
  supplier = 0xb,
  nation = 0xc
} TABLE_NUM;

typedef struct SNAPSHOT_COMMIT_MUTEX {
  pthread_mutex_t snapshot_commit_mutex;
  pthread_cond_t snapshot_cond;
  pthread_cond_t commit_cond;
  int snapshot_executing;
  int commit_executing;
} SNAPSHOT_COMMIT_MUTEX;

typedef struct COMMIT_MUTEX {
  pthread_mutex_t commit_OLTP_OLAP_mutex;
  pthread_cond_t commit_OLTP_cond;
  pthread_cond_t commit_OLAP_cond;
  int commit_OLTP_executing;
  int commit_OLAP_executing;
} COMMIT_MUTEX;

typedef struct SNAPSHOT_MUTEX {
  pthread_mutex_t snapshot_OLTP_OLAP_mutex;
  pthread_cond_t snapshot_OLTP_cond;
  pthread_cond_t snapshot_OLAP_cond;
  int snapshot_OLTP_executing;
  int snapshot_OLAP_executing;
} SNAPSHOT_MUTEX;

/* prototypes */

void InitSystem(void);
void InitDatabase(void);
void CreateBoss(void);
void CreateWorker(void);
void ExecOpeCommand(void);
void ThreadJoin(void);
void PrintStatistics(void);
extern int Listen(const char *);
extern int Accept(int);
extern void Send(int, void *, int);
extern void Recv(int,void*,int*);
extern void *Malloc(size_t);
extern char *SkipSpace(char *);
extern void *worker(void *);
extern void *Boss(void *);


/* global variables */

System *sys;
DATABASE *database; /* a "tenant" means "database" by created by createdb. */

//int ExecutingCommit, ExecutingSnapshot;
SNAPSHOT_COMMIT_MUTEX snapshot_commit_mutex;
SNAPSHOT_MUTEX snapshot_mutex;
COMMIT_MUTEX commit_mutex;


pthread_mutex_t read_dangerous_structure_counter_mutex;
int read_dangerous_structure_counter;
pthread_mutex_t write_dangerous_structure_counter_mutex;
int write_dangerous_structure_counter;
pthread_mutex_t commit_dangerous_structure_counter_mutex;
int commit_dangerous_structure_counter;
pthread_mutex_t OLAP_read_dangerous_structure_counter_mutex;
int OLAP_read_dangerous_structure_counter;
pthread_mutex_t OLAP_commit_dangerous_structure_counter_mutex;
int OLAP_commit_dangerous_structure_counter;
pthread_mutex_t OLAP_snapshot_dangerous_structure_counter_mutex;
int OLAP_snapshot_dangerous_structure_counter;
