/*
 * copyright (c) 2020 
 */

#include <stdio.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h> /* sockaddr_in */
#include <netdb.h>
#include "quzilla.h"
#include "c.h"

/* prototype */
int Listen(const char *);
int Accept(int);
void Disconnect(int);
void Send(int, void *, int);
void Recv(int, void *, int *);
void SendAll(Task *);
void RecvAll(Task *);
//void RecvDataFromOne(Task *, int, void *, int *);
void RecvDataFromOne(Task *, int );
int CheckDataShortage(Task *, void *, int *, int, int *);
ssize_t Recv2(int, void *, int);
void GetChar(char *, char *, int);
void GetInt(int *, char *, int);
unsigned long Checksum(unsigned short *, int);
int CreateSyncConnection(char *);
void RecvOne(Task *, int );
void SendOne(Task *, int );
int CheckDataShortage2(void *, int *, int, int *);
void SendClient(Task *, int );
void SendAllStartupPacket(Task *);
void SendOLAPStartupPacket(Task *);
void CreateAllBackendConnection(Task *);
void CreateOLAPBackendConnection(Task *);
void SendOthers(Task *);
void RecvOthers(Task *);
void SendSelect1(Task *, int);
void SendOneServer(Task *, int );
void RecvOneServer(Task *, int );
void SendPrepareToOLTPLeader(Task *);
void SendCommitAsync(Task *);
void SendPrepareToOthers(Task *);
void SendCommitAsync(Task *);
void SendRollbackPrepared(Task *, ERR *);
void RecvRollbackPrepared(Task *, ERR *);
void SendRollbackToFollowers(Task *);
void RecvRollbackFromFollowers(Task *);
void SendS_5ToFollowers(Task *);
void RecvS_5FromFollowers(Task *);
#define MAXLISTENLENGTH 100
#define READBUFSZ 262144

extern DATABASE *database;
