#include <stdio.h>
#include "c.h"
#include "command.h"

/* prototype */
void *Malloc(size_t);
void *Realloc(void *, size_t);
char *SkipSpace(char *);
void StrAppend(char *, char *);
void StrAppendForInt(char *, int);
int CountCharLen(char *);
int PopFirstStr(Command *, char *);
char * GetSecond(char *);
void GetRestCom(Command *);
char * GetValue(char *, char *);
char * GetFirst(char * );
int CountStrLen(char *);
