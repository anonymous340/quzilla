#include<stdlib.h>
#include<string.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<unistd.h>

/* prototypes */

extern int strcmp(const char *s1, const char *s2);
extern char *strerror(int errnum);
extern int strncmp(const char *s1, const char *s2, size_t n);
extern char *strdup(const char *s);
extern void *memset(void *s, int c, size_t n);
extern int printf(const char *format, ...);
extern int getopt(int argc, char * const argv[], const char *optstring);
extern void *memcpy(void *dest, const void *src, size_t n);
extern int pselect(int n, fd_set *readfds, fd_set *writefds, fd_set *exceptfds,
				   const struct timespec *timeout, const sigset_t *sigmask);
extern const char *gai_strerror(int errcode);
extern int close(int fd);
extern unsigned int sleep(unsigned int seconds);
extern int atoi(const char *nptr);
extern int system(const char *command);
extern int access(const char *pathname, int mode);
extern int stat(const char *path, struct stat *buf);
